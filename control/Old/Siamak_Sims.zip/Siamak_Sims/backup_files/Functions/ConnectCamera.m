function [vid,src] = ConnectCamera(userCameraProperties)

addpath(genpath(sprintf('%s',pwd)));


if(nargin == 1)
    if(strcmp(userCameraProperties,'openUI'))
        Properties = video_input;
    else
        data = load(userCameraProperties);
        Properties = data.Properties;
    end
elseif(exist('CameraProperties.mat','file') == 2)
    data = load('CameraProperties.mat','Properties');
    Properties = data.Properties;
else
    Properties = video_input;
end

PropertyName = fieldnames(Properties);

vid = videoinput(Properties.adaptor,Properties.ID,Properties.format);
src = getselectedsource(vid);

for i=4:length(PropertyName)
    src.(PropertyName{i}) = Properties.(PropertyName{i});
end

save('CameraProperties.mat');