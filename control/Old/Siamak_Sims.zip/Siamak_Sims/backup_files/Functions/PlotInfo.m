function [] = PlotInfo(F,C,S,P,R)


figure(F);
hold on;

if(exist('C','var'))
    plot(C(1,:),C(2,:),'bo','MarkerSize',20);
end


if(exist('S','var'))
    for i=1:size(S,2)
        text(S(1,i),S(2,i),sprintf('[%d]',i),'color','c','fontsize',16,'fontweight','bold');
        plot(S(1,i),S(2,i),'.c','MarkerSize',10);
    end
end


if(exist('P','var'))
    
    q = 0:36:360;
    cx = R*cosd(q);
    cy = R*sind(q);
    
    for i=find(~isnan(P(1,:)))
        plot(P(1,i)+cx,P(2,i)+cy,'w');
    end
end


hold off