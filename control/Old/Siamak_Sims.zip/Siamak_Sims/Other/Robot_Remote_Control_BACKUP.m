clc; clear; close all;

%% Initialize Optitrack and XBee Serial connection
init_optitrack;

% addpath(genpath(sprintf('%s',pwd)));
addpath('Utilities\');

% delete(instrfind('Type', 'serial'));
s1 = serialport('COM4',9600,'DataBits',8, 'StopBits',1);

%% Define problem parameters and variables
% global robot n N exit K u_r

N = 1; % Number of robots
exit = 0;
K = 80; % Gain
n = 2;
u_r = [0;0;0];


u_data = zeros(6,1);
u_type = 'uint8';
u_converter = @(x)unit8(x);


%% Initialize robot properties for all robots 1:N
for i=1:N
%     robot(i).ID = i;
%     robot(i).u.data = zeros(6,1); 
%     robot(i).u.type = 'uint8';
%     robot(i).u.convertor = @(x)uint8(x);
    A(i) = robot('N',N,'K',K,'n',n,'u_r','exit',exit,'u_type',u_type,...
        'u_data',u_data,'u_converter',u_converter,'ID',i);
end

%% Set agent's direction and velocity (vel doesnt change unless K changes)
figure('KeyPressFcn',@getKey);
drawnow();

%% Get object's rotation as a rigid body from Optitrack
read_rigidbodys_frame_optitrack
RigidBody

%% Send info to each robot via serial comms.
while(~exit)
    pause(0.1);
    for i=1:N
        % Send actuator command 192 to all robots containing that robot's
        % 'robot.u' information (which is updated in the getKey fn.)
        SerialCommunication(s1,A(i),192,'u');
    end
end

%% After exit command, STOP all robot motions
for i=1:N
    robot(i).u.data = zeros(6,1);
    SerialCommunication(s1,robot(i),192,'u');
end
clear s1

%% Disconnect Optitrack
disconnect_optitrack;

%% Helper function to get keystroke
function getKey(~, event)
    global robot n N exit K u_r
    
    map = 1; % Turn on if you want to control
    c = event.Key;
    %% Method to change robot we are controlling - I ELIMINATED THIS
    number = str2num(c);
    if(~isempty(number))
        if(number <= N  && number > 0)
            robot(n).u.data = zeros(6,1);
            n = number;
            fprintf('Changing robot to #%d\n',number);
        end
    end
    %%

    switch(c)
        case 'leftarrow'
            u_r = [0;-K;0];
        case 'rightarrow'
            u_r = [0;K;0];
        case 'uparrow'
            u_r = [K;0;0];
        case 'downarrow'
            u_r = [-K;0;0];
        case 'z'
            u_r = [0;0;K];
        case 'x'
            u_r = [0;0;-K];
        case 's'    
            u_r = [0;0;0];
        case 'hyphen'
            K = K - 1;
            if(K < 1)
                K = 0;
            end
            u_r(u_r ~= 0) = K;
            fprintf('K changed to %d \n',K);
        case 'equal'
            K = K + 1;
            fprintf('K changed to %d \n',K);
            u_r(u_r ~= 0) = K;
        case 'escape'
            fprintf('Exiting control...\n');
            exit = 1;
    end
    
    if(map == 1)
        temp = [1.7322, 1, 1;
                0, -2, 1;
                -1.7322, 1, 1];
        f = temp*u_r;
        for k=1:3 % Loop through f ~ motor values [front L, rear, front R]'
            for n=1:N % Loop through each robot
                if(f(k) >= 0) % Set positive registry to our gain
                    robot(n).u.data(2*k-1,1) = 0;
                    robot(n).u.data(2*k,1) = uint8(abs(f(k)));
                else
                    robot(n).u.data(2*k-1,1) = uint8(abs(f(k)));
                    robot(n).u.data(2*k,1) = 0;
                end
            end
        end
    end

end