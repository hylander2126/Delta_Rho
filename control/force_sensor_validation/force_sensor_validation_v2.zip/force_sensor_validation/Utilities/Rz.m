function R = Rz(th)

R = [cos(th), -sin(th); sin(th), cos(th)];

end