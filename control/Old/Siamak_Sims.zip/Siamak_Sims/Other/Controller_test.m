clc; clear; close;


f = @(ex,ey,eq,q) [ eq/3 - ex*(sin(q)/3 + (3^(1/2)*cos(q))/3) + ey*(cos(q)/3 - (3^(1/2)*sin(q))/3);
                                                          eq/3 - (2*ey*cos(q))/3 + (2*ex*sin(q))/3;
                    eq/3 - ex*(sin(q)/3 - (3^(1/2)*cos(q))/3) + ey*(cos(q)/3 + (3^(1/2)*sin(q))/3)];
                


delete(instrfind('Type', 'serial'));

BaudRate = 57600;

% Originally COM6
s1 = serial('COM4','BaudRate',BaudRate,'DataBits',8, 'StopBits',1); % Was /dev/cu.usbserial-DA01HMES
fopen(s1);


if(s1.BytesAvailable ~= 0)
    fread(s1,s1.BytesAvailable,'int8');
end


X = [1:10:2000;
     -1:-10:-2000;
     1:1:200];

 
u_ = [];
Kp = 1;

L = 1;
H = L;

for i=L:H
    
    
    F(:,i) = f(-X(1,i),-X(2,i),-X(3,i),X(3,i));
    
    for n=1:3
        if(F(n,end) >= 0)
            u_(2*n-1,i) = 0;
            u_(2*n,i) = uint8(Kp*F(n,end));
            
            
            
        else
            u_(2*n-1,i) = uint8(Kp*F(n,end));
            u_(2*n,i) = 0;
        end
    end
        
    
    
    fwrite(s1,85, 'uint8');
    fwrite(s1,241, 'uint8');
    
    fwrite(s1,X(1,i), 'int16');
    pause(0.1);
    fwrite(s1,X(2,i), 'int16');
    pause(0.1);
    fwrite(s1,X(3,i), 'int16');

    pause(0.01);
    
    fwrite(s1,85, 'uint8');
    fwrite(s1,113, 'uint8');
    pause(0.01);
    
    data = fread(s1,3,'int16');
    A(:,i) = data;

    for n=1:3
        subplot(3,1,n)
        plot(X(n,:),'-ob'); hold on
        plot(A(n,:),'-*m'); hold off
        xlim([L H]);
    end
    
    disp(A);

    
    data = fread(s1,6,'uint8');
    u(:,i) = data;
    
    for n=1:6
        subplot(6,1,n)
        plot(u_(n,:),'-ob'); hold on
        plot(u(n,:),'-*m'); hold off
        axis([0 k -5 260]);
    end
    drawnow();
    
end


    
fclose(s1);