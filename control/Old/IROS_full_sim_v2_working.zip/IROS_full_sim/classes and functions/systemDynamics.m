function [dy, bounds, desired_direc]= systemDynamics(t,y,pd,A,O,Q)

%__________________________________________________________________________
% y vector decomposition
%
% y(1:6) = [po' dpo']';
% y(6*i+1 : 6*i+3) = pa_i';

dy = zeros(length(y),1);

po = y(1:3);
dpo = y(4:6);

O.move(po,dpo);

F = [0;0];
M = 0;
mode = 0;

%% NOTE: for IROS, resubmitting failed ICRA paper. So ONLY CoM search: mode=1 always

% If all agents in CoM search mode
if all([A.com_mode])
    mode = 1; % Activate com mode
% If all agents attached and NOT in CoM search mode
elseif all([A.attached]) && ~all([A.com_mode])
    mode = 2; % Activate manipulation mode
% Otherwise, agents in attachment mode, set payload as temporary obstacle
else
    VQ1 = [O.getBodyPoint(30)];
    Q = obstacle('Vertices',VQ1); % Delete obstacle (inefficient, runs every loop)
end


% Agent and Payload dynamics
for i=1:length(A)

    A(i).move(y( 6*i+1 : 6*i+3 ));
    
    [f,m] = A(i).agentForce(t,pd,O,Q,mode);
 
    F = F + f;
    M = M + m;
    
    dy(6*i+1:6*i+3) = A(i).kinematics(t,O,Q);
end

dy(1:6) = O.dynamics(F,M,mode);

global Bounds
Bounds = [Bounds; t, A.negBound', A.posBound'];


bounds = [A.negBound', A.posBound'];
desired_direc = A.actual_direc'; % A.desired_direc';

% drawnow();