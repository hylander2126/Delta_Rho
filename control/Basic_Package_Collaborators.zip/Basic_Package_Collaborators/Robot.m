classdef Robot
    properties
        % Static properties
        ID          % Robot number (same as labeled and XBee)
        stop        % Stop condition
        % Agent motor values
        u           % Action (input)
        u_r         % Reference (desired)
        % Robot Jacobian 
        J_r
        % Robot PID control parameters
        Kp          % Proportional Gain
        Kd          % Derivative Gain
        Ki          % Integral Gain
        negBound    % Clockwise-most bound
        posBound    % Counter-Clockwise-most bound
        init_negB   % INITIAL negative bound
        init_posB   % INITIAL positive bound
        t_prev      % Previous timer value
        e_prev      % Previous angular velocity error
        prev_pay_th  % Previous angular velocity
        I_e         % Integral term
        % Atttude PID parameters
        Kw          % Rotational Proportional Gain
        e_th_prev   % Previous attitude error
        I_e_th      % Integral term for attitude correction
        f_initial   % Initial force reading for attitude correction
        low_e_ctr
        f_prev
        d_prev      % Robot driving direction
        att_status  % Toggle for attitude correction status 0=corrected 1=uncorrected
        % Dummy field for switching mode
        empty
        % Previous control 'baseline' step values
        baseline_rot % Payload orientation from previous baseline
    end

    methods
        function obj = Robot(ID)
            global opti_theta
            % Constructor
            obj.ID          = ID;
            obj.stop        = false;

            obj.u.data      = zeros(6,1);
            obj.u.type      = 'uint8';
            obj.u.convertor = @(x) uint8(x);
            obj.u_r         = [0; 0; 0];
            obj.J_r         = new_Jr_construct(); % construct_robot_jacobian('EE'); % for end effector or center

            obj.Kp          = 140; % 170   
            obj.Kd          = 0.5;
            obj.Ki          = 0;
            obj.negBound    = [1; 0.1];
            obj.posBound    = [-1; 0.1];
            obj.init_negB   = [1; 0.1];
            obj.init_posB   = [-1; 0.1];
            obj.t_prev      = 0;
            obj.e_prev      = 0;
            try
                obj.prev_pay_th = opti_theta(2);
            catch
                obj.prev_pay_th = 0;
            end
            obj.I_e         = 0;

            obj.Kw          = 150;
            obj.e_th_prev   = 0;
            obj.I_e_th      = 0;
            obj.f_initial   = [];
            obj.low_e_ctr   = 0;
            obj.f_prev      = 0;
            obj.d_prev      = [0; 0];
            obj.att_status  = 0;
            
            try
                obj.baseline_rot= opti_theta(2);
            catch
                obj.baseline_rot= 0;
            end
        end

        %% Set motor torques using calculated desired motion (u_r)
        function obj = setTorques(obj, u_r)
            % Calculate motor torque values using ROBOT Jacobian
            f = obj.J_r * u_r;
        
            % Assign robot motor torques
            % k=1 front left; k=2 rear; k=3 front right
            for k = 1:3
                if (f(k) >= 0)
                    obj.u.data(2*k - 1  , 1) = 0;
                    obj.u.data(2*k      , 1) = uint8(abs(f(k)));
                else
                    obj.u.data(2*k - 1  , 1) = uint8(abs(f(k)));
                    obj.u.data(2*k      , 1) = 0;
                end
            end
        end
    end
end

%% Script to get new Jacobian based on desired null space control

%% ========= RECALL AGENT FRAME =========
%                       * Sensor EE
%                       .
%             beta2 /   .
%                  /    y
% Wheel 2 -> _    O - - ^ - - O  <- Wheel 1
%         h1 |     \    |    / \
%            -      \  {b}-->x  \ beta1
%            |       \     /
%         h2 |        \   /
%            |         \ /
%            _  beta3---O  <- Wheel 3
%                 |<--- w --->|
% NOTES: 
% wheel center to body edge     ~ 11 mm (more like 14 mm w/ new body)
% {b} to front edge             ~ 36.88 mm (more like 36 mm)
% front edge to sensor tip      ~ 50.1 mm (more like 52 mm)

function J = new_Jr_construct(varargin)
%% ========= Jacobian decomposition =========
% Distance 'd'
    w   = 88.7694 + 2*cosd(30)*11;  % mm, more like (~89 mm + ...)
    h1  = 25.6235 + sind(30)*11;    % mm, more like (~24 mm + ...)
    h2  = 51.25 + 11;             % mm, more like (~51 mm + ...)
% Wheel radius 'r'
    r = 19;                       % mm
% Angle between the wheels DRIVING DIRECTION and the positive X axis
    beta = [-pi/3; pi/3; pi];
%% Distance FROM center of rotation TO wheel center
    C = [w/2 h1; -w/2 h1; 0 -h2];                         % Confirmed
        
    if nargin
    % For rotation about sensor (default/resting state)
        sx = 0;                   % To sensor x from {b} (mm)
        sy = 36.88 + 0 + 50.1;   % To sensor y from {b} (mm) 
        % (36 is front edge to {b}, 50 is resting y distance to front edge, mid # is empirical factor)
        
        COR = [-sx -sy; -sx -sy; -sx -sy]; % center of rotation to {b}
        C = C + COR;
    end

%% Calculate Jacobian: formula from 'Modern Robotics'
    J = zeros(3);
    % Of the form (FR, FL, R)
    for i = 1:3
        J(i,:) = (1/r) * [1 0] * [cos(beta(i)) sin(beta(i)); -sin(beta(i)) cos(beta(i))] * [-C(i,2) 1 0; C(i,1) 0 1];
    end
    
    % For current robot where wheels are actually (FL, R, FR)
    J = [J(2,:); J(3,:); J(1,:)];
end

