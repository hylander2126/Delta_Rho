syms fx2 fy2 fx3 fy3 F1 F2 F3 F4 theta alpha gamma T23

% theta is angle between link2 and horizontal
% alpha is angle between link2 and link3
% gamma is angle between link3 and link4

% T23 is tension in link 2-3
% F1 is force due to rotary spring at joint 1
% F3 is UNKOWN force
% F4 is force due to rotary spring at joint 4

% Link 2:
F3 * cos(theta) - T23 * cos(alpha) == 0
F3 * sin(theta) - T23 * sin(alpha) - F1 == 0    % Force at joint 1

% Link 3:
-T23 * cos(alpha) - F4 * cos(gamma) == 0        % Force at joint 4
-T23 * sin(alpha) - F4 * sin(beta) - F3 == 0    % Force at joint 3




