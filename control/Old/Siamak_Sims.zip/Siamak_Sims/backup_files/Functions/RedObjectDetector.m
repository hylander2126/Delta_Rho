function [objects] = RedObjectDetector(I,markers)


I1 = I(:,:,1) - I(:,:,2);
I2 = I(:,:,1) - I(:,:,3);

Im = I1 > markers.d_RG & I2 > markers.d_RB;



Im_fill = imfill(Im,'holes');

area_Im = xor(bwareaopen(Im_fill,markers.nPL),  bwareaopen(Im_fill,markers.nPH));


objects = regionprops(area_Im, 'Centroid');

% 
% figure();
% ax(1) = subplot(2,2,1); imshow(I); title('I');
% ax(2) = subplot(2,2,2); imshow(Im); title('Im');
% ax(3) = subplot(2,2,3); imshow(Im_fill); title('Im_fill');
% ax(4) = subplot(2,2,4); imshow(area_Im); title('area');
% linkaxes(ax,'xy');


