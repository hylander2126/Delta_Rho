function R = Rz2d(q)

R = [cosd(q),-sind(q);sind(q),cosd(q)];

end