clc; clear; close;

BaudRate = 57600;
SampleWindow = 200;
Vref = 3.2;

delete(instrfind('Type', 'serial'));




fprintf('Serial port initialization...\n');
s1 = serial('/dev/cu.usbserial-DA01HMES','BaudRate',BaudRate,'DataBits',8, 'StopBits',1); % Was COM6
fopen(s1);
fprintf('Port is open.\n');

if(s1.BytesAvailable ~= 0)
    fread(s1,s1.BytesAvailable,'int8');
end


stop = uicontrol('style','toggle','string','stop', ...
   'background','white');

drawnow();

voltage = zeros(2,SampleWindow);
axis_ = [0 SampleWindow Vref*([-0.1 1.1])];
%axis_ = [0 SampleWindow Vref*([0 0.02])];

while ~get(stop,'value')
    fwrite(s1,'0', 'uint8');
    data = fread(s1,2,'uint16')';
    
    voltage(:,1:end-1) = voltage(:,2:end);
    voltage(:,end) = Vref*data'/1024; 
    
    ax1 = subplot(2,1,1);
    plot(voltage(1,:),'b');
    axis(axis_);
    ylabel('V_0');
    
    ax2 = subplot(2,1,2);
    plot(voltage(2,:),'r');
    axis(axis_);
    ylabel('V_3');
    drawnow();
end

fprintf('Closing the serial port...\n');
fclose(s1);
linkaxes([ax1,ax2],'xy');