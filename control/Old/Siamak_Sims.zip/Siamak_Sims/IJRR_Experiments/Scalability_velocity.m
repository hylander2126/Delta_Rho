clc; clear all; close all;

addpath('\\research.wpi.edu\srl\Projects\Ant\Delta_Rho\Motion capturing and communication\IJRR_Experiments\Scalability-500_500_20');

RobotPopulation = 5;
type = {'Decent'};
extension = '500_500_20.mat';
% 
% type = {'dect_'};
% ext1 = 'form_';
% ext2 = '_to_0_degree';
% forms = {'120'};

lineType = {'-','--'};

cm = cool(length(RobotPopulation));
%  cm(end-1,:) = [0.9856    0.7372    0.2537];

traj_comp = figure(); hold on;  grid on; box on
t_max =3.5;
for exp = 1 : length(RobotPopulation)
    for itr = 1 : length(type)
        clear expr_data expr_time
        fileName = sprintf('%d_%s_%s',RobotPopulation(exp),type{itr},extension);
        load(fileName,'expr_data','expr_time');
        p = expr_data(:,:,end);
        dp = diff(p);
        dp(1,:) = [];
        
        dt = diff(expr_time);
        dt(1) = 150;
        
        for j=1:size(p,1)-2
            dp(j,:) = dp(j,:)/dt(j);
        end
        
        I = find(expr_time <= t_max);
        
        time = expr_time([I I(end)+1]);
        time(1) = [];
        
        dp = dp(I,:);
        dt = dt(I);
        
        s = sqrt( dp(:,2).^2 + dp(:,1).^2 );
        s_mean = mean(s);
        d=rms(s-s_mean);
        k=d./s_mean;
        
        plot(time,s/100,lineType{itr},'LineWidth',2,'color',cm(exp,:));
%         plot([time(1) time(end)],[k  k],lineType{itr},'LineWidth',2,'color','r');
        
        %                 axis([0 2 -10 200]);
        
        %         subplot(2,1,2); hold on;
        %         plot(expr_time(3:end),dp(:,3),lineType{itr},'LineWidth',2,'color',cm(exp,:));
        % %         axis([0 8 -1 40]);
        %
        %         subplot(3,1,3); hold on;
        %         plot(expr_time,dp(:,3),lineType{itr},'LineWidth',2,'color',cm(exp,:));
        %         axis([0 8 -5 5]);
    end
end
% 



%plot(500,500,'+','MarkerSize',40,'color','r','LineWidth',2);

% axis equal
% axis([350 550 120 550]);
% grid on
% % legend('0g',weights{2:end})
% box on
% %
% set(gca,'FontName','Times New Roman');
% xlabel({'x [mm]'},'FontName','Times New Roman');
% ylabel({'y [mm]'},'FontName','Times New Roman');