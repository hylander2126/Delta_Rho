%__________________________________________________________________________
% >> RobotTracking
%
%  Authors: Siamak Ghorbani Faal & Shadi Tasdighi Kalat
%           sghorbanifaal@wpi.edu & stasdighikalat@wpi.edu
%
% Revision: 1.2
%           July 24, 2015
%
%
% RobotTracking identifies and tracks each robot that is marked with 3
% markers. The markers need to have following distance constraints to be
% identified as a robot.
%                           O   <- Marker 1
%                          / \
%                         /   \
%                   2d   /  x  \   2d
%                       /   ^   \
%                      /    |    \
%   Marker 3 (2) ->   O y<--*     O  <- Marker 2 (3)
%
%                     |<--- d --->|
%
%
%
% Inputs:
%         S: System State. S has the following format:
%
%            S = [ x1  x2 ...  xN          % x positions
%                  y1  y2 ...  yN          % y positions
%                 dx1 dx2 ... dxN          % x velocity
%                 dy1 dy2 ... dyN          % y velocity
%                  f1  f2 ...  fN];        % Lost frames
%
%            where fi = 0 -> The object was visible and detected in the
%                            last frame.
%                  fi < 0 -> The number of frames that the object was not
%                            visible.
%
%    idList: List of the markers that identify each robot. If the list is
%            empty, function will run the robot detection subroutine and
%            retun back the idList as an output. The idList output of the
%            function has to be used as an input in the next function call.
%            idList has the following array structure:
%
%
%                       Robot 1   Robot 2         Robot N
%                          |         |               |
%                          V         V               V
%
%            idList = [ Marker 1, Marker 1, ... , Marker 1
%                       Marker 2, Marker 2, ... , Marker 2
%                       Marker 3, Marker 3, ... , Marker 3];
%
%       eps: Maximum accepted error in calculating marker distances
%
% Outputs:
%
%         X: Position and orientation of the robots. X matrix has the
%            following structure:
%
%            X = [ x1, x2, x3, ... , xN
%                  y1, y2, y3, ... , yN
%                  q1, q2, q3, ... , qN];
%
%    idList: Upadated idList for robot markers
%
%
%
% Revision History:
%      1.1: The initial version
%      1.2:
%__________________________________________________________________________

function [robots] = RobotTracking (robots, S , settings)

idList = [];

if(length(robots) == 1 && isempty(robots(1).ID))
    
    N = size(S,2);
    d = zeros(N,N);
    
    for i=1:N
        for j=i+1:N
            d(i,j) = norm(S(1:2,i)-S(1:2,j));
            d(j,i) = d(i,j);
        end
    end
    
    
    dedicatedId = zeros(1,N);
    
    
    for i=1:N
        
        if(dedicatedId(i) == 1)
            continue;
        end
        
        I1 = [1:i-1,i+1:N];
        I2 = I1;
        for j = I1
            I2(I2==j) = [];
            for k = I2
                if( abs( d(i,j) - d(i,k) ) < settings.eps )
                    if ( abs ( d(i,j) - settings.n*d(j,k) ) < settings.eps )
                        idList(:,end+1) = [i;j;k];
                        dedicatedId([i,j,k]) = [1 1 1];
                    end
                    
                elseif ( abs( settings.n*d(i,j) - d(i,k) ) < settings.eps  )
                    if ( abs ( d(i,k) - d(j,k) ) < settings.eps )
                        idList(:,end+1) = [k;i;j];
                        dedicatedId([i,j,k]) = [1 1 1];
                    end
                    
                elseif ( abs( d(i,j) - settings.n*d(i,k) ) < settings.eps )
                    if ( abs ( d(i,j) - d(j,k) ) < settings.eps )
                        idList(:,end+1) = [j;k;i];
                        dedicatedId([i,j,k]) = [1 1 1];
                    end
                    
                end
            end
        end
        
    end
    
    %----------------------------------------------------------------------
    %   Computing average distance between markers 2 and 3
    
    d_ = 0;
    for n=1:size(idList,2)
        d_ = d_ + norm( S(:,idList(2,n))-S(:,idList(3,n)) );
    end
    d_ = d_/size(idList,2);
    %----------------------------------------------------------------------
    %   Updating robots
    
    for n=1:size(idList,2)
        robots(n).ID = n;
        robots(n).Detectors = idList(:,n);
        robots(n).x0 = [d_;d_;1].*settings.offset;
    end
    
end


for n=1:length(robots)
    
    id = robots(n).Detectors;
    
    xd(1,1) = ( S(1,id(2)) + S(1,id(3)) )/2;
    xd(2,1) = ( S(2,id(2)) + S(2,id(3)) )/2;
    xd(3,1) = atan2( S(2,id(1)) - xd(2) , S(1,id(1)) - xd(1) );
    
    cos_d = cos(xd(3));
    sin_d = sin(xd(3));
    
    robots(n).x(:,1) = xd + [cos_d*robots(n).x0(1) - sin_d*robots(n).x0(2);
        sin_d*robots(n).x0(1) + cos_d*robots(n).x0(2);
        robots(n).x0(3)];
end



