%__________________________________________________________________________
% >> ObjectTracking
% 
%  Authors: Siamak Ghorbani Faal & Shadi Tasdighi Kalat
%           sghorbanifaal@wpi.edu & stasdighikalat@wpi.edu
%
% Revision: 1.2
%           August 10, 2015
%
%
% ObjectTracking tracks objects that are detected in sequential images 
% based on the predicted position of each object in previous frames. The 
% predicted position for each object is computed by the following equation:
%
%       Object velocity ->  v = dx + sign(dx)*f
%       Object position ->  x = x0 + t*v;
%                          dx = x - x0;
%
% Inputs:
%         C: Position of the detected objects 
%        OS: Old State of the system. The S output of the function has to
%            be used as OS in the next function call.
%         t: time passed from the last frame
%       MLF: Maximum permitted lost frames for an object (the object will
%            be deleted if it is not visible in the last MLF frames.
%         R: Acceptable proximity radius to the predicted position of an 
%            object
%
% Outputs:
%         S: System State. S has the following format:
%
%            S = [ x1  x2 ...  xN          % x positions
%                  y1  y2 ...  yN          % y positions
%                 dx1 dx2 ... dxN          % x velocity
%                 dy1 dy2 ... dyN          % y velocity
%                  f1  f2 ...  fN];        % Lost frames
%
%            where fi = 0 -> The object was visible and detected in the 
%                            last frame.
%                  fi < 0 -> The number of frames that the object was not
%                            visible.
%
%         P: Predicted position for each object:
%
%            P = [Px1x  Px2 ... PxN
%                 Py1y  Py2 ... PyN];
%
% ------------------------------------------------------------------------
% Revision History:
%      1.1: The initial version
%      1.2: P is added as an output
%__________________________________________________________________________

function [S,P] = ObjectTracking (C,OS,t,MLF,R)

% Number of previousely tracked objects
Np = size(OS,2);

% Number of detected objects
Nd = size(C,2);

% Initialize Positions to zero
S = zeros(5,Np);

if(isempty(OS))         % If there is no priori information...
    if(Nd ~= 0)
        S = zeros(5,Nd);
        S(1:2,:) = C;
        P = S;
    else
        S = [];
        P = [];
    end
    return
end


Ad = zeros(1,Nd);       % Assigned detected objects

P = zeros(2,Np);

for k = 1 : Np
    
    % if the object was not visible for more than MaxLostFrames
    if (OS(5,k) < MLF)
        S(:,k) = [NaN;NaN;NaN;NaN;OS(5,k)-1];
        continue;
    end
    
    v = OS(3:4,k);% + sign(OS(3:4,k))*OS(5,k);
    P(:,k) = OS(1:2,k) + v;% Predicted position for k-th marker
    
    
    d_ = R;
    minIndex = 0;
    for n = 1 : Nd
        d = norm(C(:,n) - P(:,k));
        if( d < d_)
            minIndex = n;
            d_ = d;
        end
    end
    
    if(minIndex == 0)
        %S(:,k) = [OS(1:4,k);OS(5,k)-1];
        S(:,k) = [OS(1:2,k)+OS(3:4,k);OS(3:4,k);OS(5,k)-1];
    else
        S(:,k) = [C(:,minIndex) ; C(:,minIndex) - OS(1:2,k) ; 0];
        Ad(minIndex) = 1;
    end
    
end

newMarker = find(Ad == 0);

for i = newMarker 
    S(:,end+1) = [C(:,i) ; 0 ; 0 ; 0];                          %#ok<AGROW>
end