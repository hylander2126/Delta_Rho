
clc; clear; close all;

imaqreset;


addpath(genpath(sprintf('%s',pwd)));



k = 1; % frame counter

[vid,src] = ConnectCamera();


set(vid,'FramesPerTrigger',Inf,'TriggerRepeat',Inf);
%vid.FramesPerTrigger = Inf;
%vid.FrameGrabInterval = 0.5;
start(vid);

figure();
stop = uicontrol('style','toggle','string','stop');




while(~get(stop,'value'))

        M(k).cdata = getdata(vid,1);
        flushdata(vid);
        IM = M(k).cdata;
        imshow(IM);
        
        pause(0.01); % red detection
        pause(0.02); % ExtractCentriod + ObjectTracking + RobotTracking
        pause(0.045); % Serial Communication time
        
        drawnow();
        %M(k) = getframe();
        k = k + 1;
end

closepreview(vid);
flushdata(vid);
delete(vid);