clc; clear; close all;

addpath(genpath(sprintf('%s',pwd)));


delete(instrfind('Type', 'serial'));
BaudRate = 57600;
s1 = serial('/dev/tty.usbserial-DA01HMES','BaudRate',BaudRate,'DataBits',8, 'StopBits',1); % Was 'COM6'
fopen(s1);

dllPath = fullfile('Z:\OptiTrack\MATLAB Connection\NatNet_SDK_2.8\NatNetSDK\lib\x64\NatNetML.dll');
assemblyInfo = NET.addAssembly(dllPath);


theClient = NatNetML.NatNetClientML(0);
HostIP = char('130.215.48.201');
theClient.Initialize(HostIP, HostIP);
global ready position aH p
ready = 0;
position = [0;0];


f1 = figure();
hold on
axis equal;
aH = gca;
set(aH,'Xlim',[-10 10],'Ylim',[-10 10],'ButtonDownFcn',@getApoint);
point = fill(Cx(p),Cy(p),'c');
stop = uicontrol('style','toggle','string','stop');
axis([-0.1 1.3 -0.1 1.3]);
grid on


xlabel('x'); ylabel('y');


% P=[-10 -100 50; 60 10 -45];
P=[0 -112.58 112.58; 130 -65 -65];
N = 3;


object.x.data = [];
object.xd.data=[];

object.dx = [0 0 0]';
object.dxd = [0 0 0]';



for n=1:N
    
    robot(n).ID = n;
    robot(n).Kp = 0.5;
    robot(n).Kd = 0.1;
    
    
    robot(n).x.data = [100 200 -300]';
    robot(n).x.type = 'int16';
    robot(n).x.convertor = @(x)int16(x);
    
    robot(n).xd.data = [220 -500 450]';
    robot(n).xd.type = 'int16';
    robot(n).xd.convertor = @(x)int16(x);
    
    robot(n).u.data = [];
    robot(n).u.type = 'uint8';
    robot(n).u.convertor = @(x)uint8(x);
   
    robot(n).dx = [0 0 0]';
    robot(n).dxd = [0 0 0]';
    robot(n).J = construct_jacobian(P(:,n));
    robot(n).pJ_ = pinv(construct_jacobian(P(:,n)));
    
    robot(n).dg = 70;
end

for n=1:N+1
    arrow(n) = quiver(1,1,1,1,0,'MaxHeadSize',10,'LineWIdth',2);
end


frameOfData = theClient.GetLastFrameOfData();


% for n=1:N
%     R = frameOfData.RigidBodies(n);
%     x = R.x;
%     y = R.y;
%     Q = [R.qw R.qx R.qy R.qz];
%     [q,~,~] = quaternions2euler(Q);
%     
%     robot(n).xd.data = [x*1000;y*1000;q*57.2958];
%     u = 0.2*cos(q);
%     v = 0.2*sin(q);
%     set(arrow(n),'xdata',x,'ydata',y,'udata',u,'vdata',v)
% end



R = frameOfData.RigidBodies(N+1);
x = R.x;
y = R.y;

Q = [R.qw R.qx R.qy R.qz];
[q,~,~] = quaternions2euler(Q);
object.xd.data = [x*1000;y*1000;q*57.2958];

object.dxd=[0;0;0];
p_x=object.xd.data;
u = 0.2*cos(q);
v = 0.2*sin(q);
set(arrow(N+1),'xdata',x,'ydata',y,'udata',u,'vdata',v);
   
tic;

x_hist = zeros(3,100);
dx_hist=zeros(3,100);


while(~get(stop,'value'))

    frameOfData = theClient.GetLastFrameOfData();
    R = frameOfData.RigidBodies(N+1);
    x = R.x;
    y = R.y;
    
    Q = [R.qw R.qx R.qy R.qz];
    [q,~,~] = quaternions2euler(Q);
   
    time=toc;
    object.xd.data=[p];
    Cx = @(p) p(1)+ [2 1 1].*cosd((0:120:240)+p(3));
    Cy = @(p) p(2)+ [2 1 1].*sind((0:120:240)+p(3));
    object.x.data = [x*1000;y*1000;q*57.2958];
    object.dx=(object.x.data-p_x)/time;
    p_x=object.x.data;
    tic;
    u = 0.2*cos(q);
    v = 0.2*sin(q);
    x_hist(:,1:end-1) = x_hist(:,2:end);
    x_hist(:,end) = object.x.data;
    
    dx_hist(:,1:end-1) = dx_hist(:,2:end);
    dx_hist(:,end) = object.dx;
    

    %x_hist(:,end+1) = object.x.data;
    
    %figure(f2);
%     subplot(2,1,1);
%     plot(x_hist')
%     subplot(2,1,2);
%     plot(dx_hist')
    
    
    %figure(f1);
    set(arrow(N+1),'xdata',x,'ydata',y,'udata',u,'vdata',v)
    set(point,'Xdata',Cx(p),'Ydata',Cy(p));
    
    for n=1:N
        R = frameOfData.RigidBodies(n);
        x = R.x;
        y = R.y;
        Q = [R.qw R.qx R.qy R.qz];
        [q,~,~] = quaternions2euler(Q);
        
        robot(n).x.data = [x*1000;y*1000;q*57.2958];
        robot(n)=updateRobot(robot(n),object,'Force');
        SerialCommunication(s1,robot(n),192,'u');
        
        u = 0.2*cos(q);
        v = 0.2*sin(q);
        set(arrow(n),'xdata',x,'ydata',y,'udata',u,'vdata',v)
        
    end
    
 
    drawnow();

end

for n=1:N
    arrow(n) = quiver(1,1,1,1,0,'MaxHeadSize',10,'LineWIdth',2);
end

for n=1:N
    robot(n).u.data = zeros(6,1);
    SerialCommunication(s1,robot(n),192,'u');
end


close(f1);



theClient.Uninitialize; % disconnect
theClient.delete;
fclose(s1);

