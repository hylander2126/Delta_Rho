
clc; clear; close;

global ready position aH x
ready = 0;
position = [0;0];

x = [0;0;0];
Cx = @(x) x(1)+ [2 1 1].*cosd((0:120:240)+x(3));
Cy = @(x) x(2)+ [2 1 1].*sind((0:120:240)+x(3));

f = figure(); hold on
axis equal
stop = uicontrol('style','toggle','string','stop');

grid on

aH = gca;

set(aH,'Xlim',[-10 10],'Ylim',[-10 10],'ButtonDownFcn',@getApoint);

point = fill(Cx(x),Cy(x),'c');


while(~get(stop,'value'))
    set(point,'Xdata',Cx(x),'Ydata',Cy(x));
    drawnow();
end

close(f)

