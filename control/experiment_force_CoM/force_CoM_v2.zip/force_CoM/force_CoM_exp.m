clc; clear; close all;
addpath("Utilities\")
if exist('s1','var')
    delete(s1)
end

%% Open SerialPort
s1 = serialport('COM4',9600,'DataBits',8, 'StopBits',1);

%% **** AGENT ID and attachment points ****
N = 4;                                  % ACTIVE AGENT

% NOTE: If default config (robot 180deg) set to 0. Otherwise, set to 1. This changes angle wrapping from Optitrack
testPt2 = 1;                            % ATTACH POINT 0 = 180 , 1 = 0 or 1 = 360
if ~testPt2
    theta = 180;                        % Default attachment point.
else
    theta = 90;                         % Secondary attachment point.
end
r = (172/2)*[cosd(theta);sind(theta)]; % Payload radius * unit on circle


%% Define Robot Properties
% Define Agent
Robot.ID            = N;
Robot.stop          = false;    % Robot stop condition
Robot.Kp            = 150;      % Proportional Gain
Robot.Kd            = 0.5;      % Derivative Gain
Robot.Kw            = 150;      % Rotational Proportional Gain
Robot.v_desired     = 170;      % Desired velocity magnitude
% Timeout for sensor
Robot.timeout       = 0.5;
% Agent motor values
Robot.u.data        = [0;0;0];
Robot.u.type        = 'uint8';
Robot.u.convertor   = @(x)uint8(x);
% Robot Jacobian (new wheels 02/11/23) 
Robot.J_r           = construct_robot_jacobian;
% Robot resting sensor values
Robot.rest_angles   = [0;0];
Robot.rest_ee       = 0;
Robot.deadzone      = 5;        % grams
% Robot PD control parameters
Robot.u_prev        = [0;0;0];
Robot.de            = [0;0];
Robot.f_prev        = 0;
Robot.t_prev        = 0;

Robot.d_prev        = [0;0];

%% Define five-bar properties
% Static values
five_bar.spring_k   = k;
five_bar.phi        = data(1,3:4)';
five_bar.links      = links;
% Dynamic values
five_bar.home       = [0;0]; % [11.42; 53.7105]; % Base joints and EE coords
five_bar.p          = p;
five_bar.alpha      = [];
five_bar.direction  = [];
five_bar.force      = 0;
% Comparison variables
five_bar.deadzone   = 0.5; % 3.5; % grams
five_bar.window_size= 2; % Take the average of n samples for direction mean filtering
five_bar.prev_direc = [];
five_bar.ctr    = 1;


% 
s1.Timeout = Robot.timeout;
%

%% Generate figure - Used to send STOP command
% generateFigure = false;
% f1 = figure();
% f1.Position = [600, 300, 800, 500];
% hold on
% axis equal;
% stop = uicontrol('style','toggle','string','stop');
% axis([-0.2 1.5 -0.5 0.5]);
% grid on
% xlabel('x'); ylabel('y');

%% PLOTTING initialization
% circ = linspace(0, 2*pi);
% circX = (0.15)*cos(circ); % 0.15 just works...
% circY = (0.15)*sin(circ);
% 
% circle(1) = patch(circX + x(1), circY + y(1), 'k');
% arrow(1) = quiver(0,0,0.25*Robot.negBound(1),0.25*Robot.negBound(2));
% arrow(2) = quiver(0,0,0.25*Robot.posBound(1),0.25*Robot.posBound(2));
% arrow(3) = quiver(0,0,0.25*Robot.desired_direc(1),0.25*Robot.desired_direc(2));


%% Stopwatch for checking minimal rotation threshold
runTime = tic;
global PD_data force_data;
PD_data = [];
force_data = [];


%% ****** RUN EXPERIMENT *******
while toc(runTime) < 10 && ~Robot.stop
    %% Assign robot motor torques | k=1 front left; k=2 rear; k=3 front right
    t = toc(runTime);
    Robot = update_robot(t, Robot, s1);
%     pause(0.01)
end



%% Cleanup - Stop Robot motors, delete serialport
Robot.u.data = zeros(6,1);
SerialCommunication(s1,Robot,192,'u');
delete(s1)
return

%% ***** Run Experiment ******
%__________________________________________________________________________
% while(~get(stop,'value') && ~Robot.stop)
% 
%     % Update Robot and Payload properties: get x,y,z,Q,R and determine rotation
%     optitrack_read_rigidbody_frame;
%     update_robot_payload_positions;
% 
% %     disp(Robot.desired_direc);
% 
% 
%     %% Update robot's desired heading and take measurement
%     t = toc(runTime);
%     Robot = updateRobot(t,Robot,payload,s1);
%     
% 
%     % Send command to Robot
%     SerialCommunication(s1,Robot,192,'u');
% 
%     % Update plot arrow information
%     set(circle(1),'xdata',circX + x(1), 'ydata', circY + y(1));
%     set(arrow(1),'xdata',x(2),'ydata',y(2),'udata',0.25*Robot.negBound(1),'vdata',0.25*Robot.negBound(2));
%     set(arrow(2),'xdata',x(2),'ydata',y(2),'udata',0.25*Robot.posBound(1),'vdata',0.25*Robot.posBound(2));
%     set(arrow(3),'xdata',x(2),'ydata',y(2),'udata',0.25*Robot.desired_direc(1),'vdata',0.25*Robot.desired_direc(2));
% 
%     drawnow();
% end


%% Cleanup - Stop Robot motors, delete serialport
Robot.u.data = zeros(6,1);
SerialCommunication(s1,Robot,192,'u');
delete(s1)
disp("Deleted Serial Port")

% Get Final Run Time
time = round(toc(runTime),1);
disp(['Final run time: ', num2str(time)]);


%% ***** RESULTS ******
% NOTE: Measurement is taken FROM attachment point, NOT from CoM. finalMeasurement2 MUST BE NEGATED cause 180deg
%__________________________________________________________________________
pseudo_bisect = Robot.negBound + Robot.posBound;
new_direction = pseudo_bisect./norm(pseudo_bisect);

if testPt2
    finalMeasurement_360 = Rz2d(rad2deg(-payload.x.data(3))) * Robot.desired_direc % Robot.desired_direc
else
    finalMeasurement_180 = Rz2d(rad2deg(-payload.x.data(3))) * Robot.desired_direc % Robot.desired_direc
end

% For visualization (not really necessary)
set(arrow(3),'xdata',x(2),'ydata',y(2),'udata',0.25*new_direction(1),'vdata',0.25*new_direction(2));


%%
return
%%



%% Calculate and visualize intersection *AND* Save Trial

if testPt2
    save trial_2_360deg_try2.mat
else
    save trial_2_180deg_try2.mat
end


%% ********************** RUN THIS BLOCK WHEN FINISHED ********************
%% Export image and figure
fileName = ['com_phys_fig2 ' num2str(time) 's'];
exportgraphics(gca,[fileName '.png'],'Resolution',300)
saveas(gca,[fileName '.fig'])
save com_phys_fig2_9.5s
