function [direction, force] = sensor_kinematics(s1, Robot, calibration)
    
    % Read force sensor data
    sensor = [];
    sensor_time = tic;
    
    sensor = cell2mat(SerialCommunication(s1,Robot,80))'; sensor(end) = []; % Remove last element, unused

    if toc(sensor_time) > Robot.timeout
        sprintf('Took %4.2f s to read from serial...', toc(sensor_time))
%         direction = 'stop';
%         force = 'stop';
        direction = Robot.d_prev;
        force = Robot.f_prev;
        return
    end


    %% Convert current sensor data from voltage to radians, add offset (0deg is 270 wrt x-axis), and wrap to 2Pi
    % Offset - roughly 270 degrees
    offset = 280;
    theta = wrapTo2Pi(mapfun(sensor, 0, 1023, 0, deg2rad(330)) + deg2rad(offset));

    %% Define problem constraints
    % Spring constant calculation
    % For the following spring: https://www.mcmaster.com/9271K665/
    maxTorque = 0.25;   % in-lb
    maxDeflection = pi; % 180 degrees
    
    maxTorque = maxTorque * (25.4/1) * (4.448/1); % Convert in-lb to N-mm
    k = maxTorque/maxDeflection; % N-mm/rad
    
    % Define link lengths
    l1 = 25;
    l2 = 40;
    l3 = 40;
    l4 = 25;
    l5 = 22.84;
    
    % First and Last point coordinates
    A = [0; 0];
    E = [l5; 0];
       
    %% Calculate coordinates of all other joints
    % Coordinates of joint 2 and 4
    B = [l1*cos(theta(1)) ; l1*sin(theta(1))];
    D = [l5 + l4*cos(theta(2)) ; l4*sin(theta(2))];
    
    % Get distance between joints 2 and 4
    d = norm(D-B);
    
    % Calculate angle between d and l2
    alpha = acos((l2.^2 + d.^2 - l3.^2)./(2*l2.*d));
    
    % Get "V" vector with length l2 along d
    v = l2*(D - B)./d;
    
    % Calculate end effector x,y by rotating V vector by alpha
    C = Rz2(alpha) * v + B;
    

    %% IF 'calibration' MODE RETURN ONLY RESTING BASE ANGLES AND EE POSITION
    % Not actually direction and force but for simplifying code
    if calibration
        direction = theta;
        force = C;
        return
    end


    % Calculate angle between l1 & l2 and l4 & l3
    gamma1 = acos(dot(C-B, -B) / (norm(C-B)*norm(B)));          % Angle between link 1 & 2
    gamma2 = acos(dot(C-D, -(D-E)) / (norm(C-D)*norm(D-E)));    % Angle between link 3 & 4

    % Get difference between current reading and resting angle - UPDATED with NOMINAL VALUES
%     dTheta1 = Robot.rest_angles(1) - theta(1);
    dTheta1 = 1.9705 - theta(1);

%     dTheta2 = Robot.rest_angles(2) - theta(2);
    dTheta2 = 1.1711 - theta(2);

    f1 = (-k*dTheta1 / (l1*sin(gamma1)));
    f2 = (-k*-dTheta2 / (l4*sin(gamma2)));
    
    force = (abs(f1) + abs(f2)) * (1/9.807) * (1000/1);             % Sum and convert N to g-f
    
    %% Calculate direction of incoming force
    rest_ee = [11.42; 56.9806];
    direction = (C - rest_ee) / norm(C - rest_ee);
    direction([1 2]) = -direction([2 1]);
    if isnan(direction)
        direction = [0;0];
    end
end
