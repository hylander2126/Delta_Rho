

clc

disp('=================== xd =========================');

data = SerialCommunication(s1,robot,0,'xd');
disp(data{1});

data = SerialCommunication(s1,robot,128,'xd');
disp(data);

data = SerialCommunication(s1,robot,0,'xd');
disp(data{1});



disp('=================== x ==========================');

data = SerialCommunication(s1,robot,16,'x');
disp(data{1});

data = SerialCommunication(s1,robot,144,'x');
disp(data);

data = SerialCommunication(s1,robot,16,'x');
disp(data{1});



disp('=================== xO =========================');

data = SerialCommunication(s1,robot,32,'xd');
disp(data{1});

data = SerialCommunication(s1,robot,160,'xd');
disp(data);

data = SerialCommunication(s1,robot,32,'xd');
disp(data{1});


robot.x = [100 200 50]';
robot.dx = [0 0 0]';

robot.xd = [100 200 50]';
robot.dxd = [0 0 0]';

robot.Kp = 2;
robot.Kd = 1;





