%% Calibrate sensors before doing anything else on the robot
function [rest_volts, rest_ee] = calibrate_sensors(serialPort, robotID)
    % Rot matrix fn
    Rz = @(th) [cos(th), -sin(th); sin(th), cos(th)];
    
    % Request sensor data from robot
    sensor_rest = cell2mat(SerialCommunication(serialPort,robotID,80))'; % Read output
    sensor_rest = sensor_rest(1:2);
    
    % Offset - slightly different every run
    offset = 280;
    
    %% Wrap RESTING sensor data from voltage to 2pi radians, and add offset (0deg is 270 wrt x-axis)
    theta1 = wrapTo2Pi(mapfun(sensor_rest(1), 0, 1023, 0, deg2rad(330)) + deg2rad(offset));
    theta2 = wrapTo2Pi(mapfun(sensor_rest(2), 0, 1023, 0, deg2rad(330)) + deg2rad(offset));

    %% Define problem constraints
    % Spring constant calculation
    maxTorque = 0.402; % in-lb
    maxDeflection = pi; % 180 degrees
    
    maxTorque = maxTorque * (25.4/1) * (4.448/1); % Convert in-lb to N-mm
    k = maxTorque/maxDeflection; % N-mm/rad
    
    % Define link lengths
    l1 = 25;
    l2 = 40;
    l3 = 40;
    l4 = 25;
    l5 = 22.84;
    
    % First and Last point coordinates
    A = [0; 0];
    E = [l5; 0];

    %% Calculate coordinates of all other joints
    % Coordinates of joint 2 and 4
    B = [l1*cos(theta1) ; l1*sin(theta1)];
    D = [l5 + l4*cos(theta2) ; l4*sin(theta2)];
    
    % Get distance between joints 2 and 4
    d = norm(D-B);
    
    % Calculate angle between d and l2
    alpha = acos((l2.^2 + d.^2 - l3.^2)./(2*l2.*d));
    
    % Get "V" vector with length l2 along d
    v = l2*(D - B)./d;
    
    % Calculate end effector x,y by rotating V vector by alpha (rot. matrix)
    C = Rz(alpha) * v + B;
    
    % Outputs
    rest_volts = sensor_rest;
    rest_ee = C;
end

