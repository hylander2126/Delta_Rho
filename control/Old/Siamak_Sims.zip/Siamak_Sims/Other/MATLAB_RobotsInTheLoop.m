%% Initializations
clc; clear; close all;

imaqreset;
delete(instrfind('Type', 'serial'));


addpath(genpath(sprintf('%s',pwd)));


BaudRate = 57600;
n = 2;

% offset is a function of detector distance d!
robot = struct('ID',[],'x',[],'xd',[],'Detectors',[],'x0',[],'color',[]);

markers = struct('d_RG',40,'d_RB',40,'nPL',100,'nPH',500);

tracking = struct('t',0,'MLF',-15,'R',20);

settings = struct('eps',20,'offset',[sqrt(n^2-1)/2;0;0]);


s1 = serial('COM6','BaudRate',BaudRate,'DataBits',8, 'StopBits',1);
fopen(s1);


k = 1; % frame counter
L = 150; % quiver length
%========================= End of Init ===================================%

%% Updating dynamic properties

[vid,src] = ConnectCamera();

[robot,S] = DiscoverScene(vid,robot,markers,tracking,settings);


IM = getsnapshot(vid);

fig = figure();

% hold on
axis equal
% scene = imshow(IM); hold on
stop = uicontrol('style','toggle','string','stop');


for n=1:length(robot)
    if(isstr(robot(n).ID))
        if(strcmp(robot(n).ID,'object'))
            objectID = n;
            objectArrow = quiver(robot(n).x(1),robot(n).x(2),...
                L*cos(robot(n).x(3)), L*sin(robot(n).x(3)),0,...
                'LineWidth',2,'MaxHeadSize',10,'color',[35 190 200]/255);
        end
        
    end
end
robotList = [1:objectID-1,objectID+1:length(robot)];

for n = robotList
    
    [x_,y_] = ginput(1);
    robot(n).xd = [x_;y_];
    robot(n).xd(3) = 0;
    
    arrow(robot(n).ID) = quiver(robot(n).x(1),robot(n).x(2),...
        L*cos(robot(n).x(3)), L*sin(robot(n).x(3)),0,...
        'LineWidth',2,'MaxHeadSize',10,'color',[255 182 140]/255);
end

SerialCommunication(s1,robot(robotList),128,'xd');


%% Main loop

set(vid,'FramesPerTrigger',Inf,'TriggerRepeat',Inf);
%vid.FramesPerTrigger = Inf;
vid.FrameGrabInterval = 0.5;
start(vid);

while(~get(stop,'value'))
%     try
        
        IM = getsnapshot(vid);
        %IM = getdata(vid,1);
        flushdata(vid);
        
        
        objects = RedObjectDetector(IM,markers);
        
        if(isempty(objects))
            drawnow();
            continue
        end
        
        C = ExtractCentriod(objects);
        
%         set(scene,'CData',IM);
        imshow(IM);
        
        [S,P] = ObjectTracking(C,[],0,tracking.MLF,tracking.R);
        robot = RobotTracking(robot,S,settings);
        
        SerialCommunication(s1,robot(robotList),144,'x');
        
        for n = robotList
            set(arrow(robot(n).ID),'xdata',robot(n).x(1),'ydata',robot(n).x(2),...
                'udata',L*cos(robot(n).x(3)),'vdata',L*sin(robot(n).x(3)));
        end
        
        set(objectArrow,'xdata',robot(objectID).x(1),'ydata',robot(objectID).x(2),...
            'udata',L*cos(robot(objectID).x(3)),'vdata',L*sin(robot(objectID).x(3)));
%         
        PlotInfo(fig,C,S,P,tracking.R)
        drawnow()
        k = k + 1;
%     catch
%         fprintf('Error Happened! Cleaning info...\n');
%         %closepreview(vid);
%         flushdata(vid);
%         delete(vid);
%         return;
%     end
end

closepreview(vid);
flushdata(vid);
delete(vid);