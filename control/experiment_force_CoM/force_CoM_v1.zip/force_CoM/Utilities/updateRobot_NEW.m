function [Robot] = updateRobot_NEW(t,Robot,payload,s1)

%% 

%% TODO - THIS DOESNT CORRESPOND TO THE ROBOT JACOBIAN WE CALCULATE IN THAT FUNCTION. THE AXES ARE WRONG...

%% RECALL AGENT FRAME:
%                      _         O   <- Marker 1
%                      |        / \
%                      |       /   \
%                   2d |      /     \
%                      |     /       \
%                      |    /         \
%   Marker 3 (2) ->    _   O y<--*     O  <- Marker 2 (3)
%                                |
%                                v
%                                x
%
%                          |<--- d --->|

%% Jacobian Assignment
% J_rf = [-1.7322, 1, 1; 0, -2, 1; 1.7322, 1, 1]; % Jacobian mapping wheels to robot frame (between front wheels)
% J_temp = [-1.7321   1.0000    0.4226;     0    -2.0000    1.0000;   1.7321   1.0000    0.4226]; % Jacobian from calculation then modified
% J_r = 3*[-0.5774, 0.7314, 5.7504; 0, -0.2686, 5.7504; 0.5774, 0.7314, 5.7504]; % Jacobian mapping wheels to robot end effector

robotRot = rad2deg(Robot.x.data(3));
payloadRot = rad2deg(payload.x.data(3));
payloadRot_prev = rad2deg(payload.theta_prev);

global rest_volts rest_ee force_data;

%% Calibrate sensors resting state
if t < 2
    disp("Calibrating force sensor. Do not touch robot...")
    [rest_volts, rest_ee] = calibrate_sensors(s1, Robot);
    u_r = [0;0];

%% Move forward briefly to induce movement in payload
elseif t < 2.7
    u_r = Robot.v_desired .* [1;0];
    Robot.prev_direc = u_r;

    % For plotting only
    sensor = cell2mat(SerialCommunication(s1,Robot,80))'; % Read output
    sensor = sensor(1:2);
    [d,f] = sensor_kinematics(sensor, rest_volts, rest_ee);
    temp = d; % Negate to move in direction of force TODO FIX THE NEED TO SWAP 1 AND 2 IN KINEMATICS, make ref frames =
    d(1) = temp(2);
    d(2) = temp(1);
    temp = f*d;
    force_data = [force_data; t, temp(1), temp(2)];

elseif t < 2.8
    disp('')
    disp('Beginning Search')
    u_r = Robot.prev_direc;
%% Run CoM Search
else
    % Read sensors
    sensor = cell2mat(SerialCommunication(s1,Robot,80))'; % Read output
    sensor = sensor(1:2);
    
    
    %% Convert sensor voltages to applied force and direction
    [d,f] = sensor_kinematics(sensor, rest_volts, rest_ee);
    
    temp = d; % Negate to move in direction of force TODO FIX THE NEED TO SWAP 1 AND 2 IN KINEMATICS, make ref frames =
    d(1) = temp(2);
    d(2) = temp(1);
    temp = f*d;
    force_data = [force_data; t, temp(1), temp(2)];

    if abs(f) > 0.1 % Deadzone
        virtual_gain = atan(3*abs(f)) * Robot.v_desired;
%         disp(virtual_gain*Robot.v_desired)
        u_r = virtual_gain .* -d;
    else
        u_r = [0;0];
    end

%     if abs(f) > 0.1
%         
%         new_direc = com_search(d,f,Robot);
%         u_r = new_direc;
%         Robot.prev_direc = u_r(1:2);
%     else
%         u_r = [0;0];
%     end
    

end

%% Null-space control / attitude adjustment
% Maintain angle between 

% u_r(1:2,1) = [0;0];


%% Calculate attitude error term
% Get UNIT vectors of agent heading and payload heading
r = [Robot.J(3,2);-Robot.J(3,1)]; % MUST be local Jacobian NOT J_r
r = r/norm(r); % Unit vector of attachment pt to payload

% Calculate vectors representing payload & robot heading
noW = Rz3(payloadRot)*[r;0]; % ~ vector: O to r, updated w/Rot.
nrW = Rz3(robotRot)*[-1;0;0];

% Calculate error vector (atan2 gives negative values also)
e_r = -atan2d(noW(1)*nrW(2)-noW(2)*nrW(1), noW(1)*nrW(1)+noW(2)*nrW(2));

% Piecewise (adaptive control) for larger errors
if abs(e_r) > 5 % 10 for extreme case, 5 otherwise
    e_r = 1.5*(1.1^(e_r+26)); % Robot.K_wp*e_r + Robot.K_wd*sign(e_r);
end
u_r(3,1) = e_r;


%%
u_r(3,1) = 0;

%% Calculate motor torque values using ROBOT Jacobian
f = Robot.J_r*u_r;


%% Assign robot motor torques | k=1 front left; k=2 rear; k=3 front right
for k=1:3
    if(f(k) >= 0)
        Robot.u.data(2*k-1,1) = 0;
        Robot.u.data(2*k,1) = uint8(abs(f(k)));
    else
        Robot.u.data(2*k-1,1) = uint8(abs(f(k)));
        Robot.u.data(2*k,1) = 0;
    end
end

%% SEND serial communication to robot
SerialCommunication(s1,Robot,192,'u');

end
