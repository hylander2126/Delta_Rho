function R = Rz3(q)

R = [cos(q),-sin(q),0; sin(q),cos(q),0; 0,0,0];

end