c = 40.17/1000;
b = 50.16/1000;
h = 127.19/1000;

a = [60 180 300];

J1 = [cosd(a+90) ; sind(a+90) ; c*cosd(a(1))+b*sind(a(1)), h, c*cosd(a(3))+b*sind(a(3))];


%%



B = [b 0 -b];
C = [-c -h -c];

J2 = [cosd(a+90) ; sind(a+90) ; -B.*cosd(a+90)+C.*sind(a+90)];