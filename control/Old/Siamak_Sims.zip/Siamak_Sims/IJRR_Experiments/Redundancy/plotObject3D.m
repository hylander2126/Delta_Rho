function plotObject3D(x,z,color,alpha)

Q = 0:20:360;
r = 20;
R = 50;

fill3(r*cosd(Q)+x(1),r*sind(Q)+x(2),z*ones(size(Q)),color,'FaceAlpha',alpha,'EdgeColor',color);
plot3(x(1)+[1 R*cosd(x(3))], x(2)+[1 R*sind(x(3))],[z z],'color','k');