clc; clear all; close all;


figure();




x_max  = 10;
v_max = 1;
a_max = 0.5;
dt = 0.1;

f = @(x) 2*x*rand(2,1) - x; 


stop = uicontrol('Style', 'togglebutton','string','stop');


N = randi(10,1);


red_dot.id = 1;
red_dot.p = f(x_max);
red_dot.v = f(v_max);
red_dot.a = f(a_max);

for i=2:N
    red_dot(i) = struct('id',i,'p',f(x_max),'v',f(v_max),'a',f(a_max));
end


Cx = 0.2*cosd(0:20:360);
Cy = 0.2*sind(0:20:360);

k = 1;

while(~get(stop,'value'))
    
    birth_control = randi(100);
    
    if(birth_control > 98)
        red_dot(end+1) = struct('id',i,'p',f(x_max),'v', f(v_max),'a',f(a_max));
    end
    
    death_list = [];
    
    for n=1:length(red_dot)
        fill(Cx+red_dot(n).p(1),Cy+red_dot(n).p(2),'r'); hold on
         
        
        red_dot(n).a = red_dot(n).a + f(a_max);
        red_dot(n).v = red_dot(n).a*dt;
        red_dot(n).p = red_dot(n).p + red_dot(n).v*dt;
        
        
        
        if(abs(red_dot(n).p(1)) > x_max || abs(red_dot(n).p(2)) > x_max )
                death_list(end+1) = n;
        end
        
        
    end
    
    red_dot(death_list) = [];
    
    axis equal;
    axis([-x_max x_max -x_max x_max]);
    set(gca,'color','black')
    
    hold off;
    M(k) = getframe();
    k = k + 1;
    
end


movie2avi(M,'test.avi');
