%% Demo for SINGLE ROBOT manipulation with/out attitude correction
% Define which RobotID's are being utilized (two robots for now)
clc; clear; close all;

%% Open SerialPort 
% Make sure this matches your Xbee adapter com port (check device manager)
s1 = serialport('COM4',9600,'DataBits',8,'StopBits',1);
s1.Timeout = .15;


%% **** Robot and Force Sensor Definition ****
IDs = [10];       % MAKE SURE THIS MATCHES THE ROBOT ID FROM THE FIRMWARE (check Microchip Studio)
N = length(IDs);   % Number of robots
for i=1:N
    robots(i) = Robot(IDs(i));
    force_sensors(i) = ForceSensor(IDs(i));
end


%% Generate figure - Used to send STOP command
f1 = figure("Position",[600 300 800 500]); hold on;
stop = uicontrol('style','toggle','string','stop');


%% Stopwatch for checking minimal rotation threshold
t = 0;
t_start = tic;
run_time = 30; % runtime in seconds


%% ---------------   RUN EXPERIMENT   ----------------

while (t < run_time  &&  ~robots(1).stop && ~stop.Value)
    % Update ALL robots actions based on sensor data
    [robots, force_sensors] = update_this_robots(s1, N, robots, force_sensors);

    % Send serial communication to robot
    for i=1:N
        SerialCommunication(s1, robots(i), 192, 'u');
    end

    pause(0.05)
    t = toc(t_start);
end

%% --------------------------------------------------


%% Cleanup - Stop robot motors, delete serialport
robots(1).u.data = zeros(6,1);
for i=1:N
    SerialCommunication(s1,robots(1),192,'u');
end
delete(s1)
disp("Deleted Serial Port")

% Get Final Run Time
t_final = round(toc(t_start),1);
disp(['Final run time: ', num2str(t_final)]);

return

function [robots, force_sensors] = update_this_robots(s1, N, robots, force_sensors)

% RECALL AGENT AND SENSOR FRAMES:
%                           
%                      ^ x
%                      |
%         _      O     *-->y O  <- Marker 3 (2)
%         |       \         / 
%         |        \       /
%      2d |         \     /
%         |          \   /
%         |           \ /
%         _            O        <- Marker 1 (1)
%                |<--------->|
%                      d
%
%                      O p5
%                     / \
%                    /   \
%                l3 /     \ l4
%                  /       \
%                 /    ^ y  \
%                 \    |    /
%                  O   *---O--> x
    % u_r is [omega, vx, vy]
    u_r = [40;0;0]; % No robot motion unless updated explicitly

    
    % %% Cancel force sensor reading
    % for i=1:N
    %     % Read force sensor
    %     force_sensors(i) = force_sensors(i).readSensor(s1, robots(i));
    % 
    %     % Data returned by robot, defined in firmware
    %     temp = force_sensors(i).alpha;
    %     temp2 = temp/100
    %     % norm(temp2)
    % 
    %     data_sensor = [data_sensor; temp(1)/100, temp(2)/100];
    %     DIRECTION = temp(1:2)/(norm(temp(1:2)));
    % end
    % 
    %% Set new robot motor values
    for i=1:N
        robots(i) = robots(i).setTorques(u_r);
    end
end
