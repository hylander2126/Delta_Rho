clc; clear all; close all;

addpath('\\research.wpi.edu\srl\Projects\Ant\Delta_Rho\Motion capturing and communication\IJRR_Experiments\Scalability-500_500_20');

FailMode = [12 24 45];
FailTime = [2 2 2];
recoverTime = [35 35 35];

% RobotPopulation = [2 3 4 5];
% type = {'Decent'};
% extension = '500_500_20.mat';

lineType = {'-','--'};

cm = cool(length(FailMode)+1);

alpha = @(t,data) (a1-a0)/(data(end)-data(1))*(t-data(1))+a0;

t_max = [3 3 3 3];
figure(); hold on; axis equal; box on
% xlim([300 700]);
% ylim([-200 400]);
axis([-150 100 -400 50])
N = 6;
for exp = 1 : length(FailMode)
    for itr = 1 : (length(FailTime))+1
        clear expr_data expr_time
        fileName = sprintf('Fail_%d_%ds_%d',FailMode(exp),FailTime(exp),recoverTime(exp));
        load(fileName,'expr_data','expr_time');
        
        
        expr_data(:,1,N) = expr_data(:,1,N)-500;
        expr_data(:,2,N) = expr_data(:,2,N)-500;
        expr_data(:,3,N) = expr_data(:,3,N)-20;
        
        grid on% box on
        time = expr_time(expr_time <= t_max(exp));
        ct = cool(length(FailMode));
        
        
        plotObject3D(expr_data(length(time),:,N),0,ct(exp,:),0.1);
        
        set(gca,'FontName','Times New Roman');
        xlabel({'x [mm]'},'FontName','Times New Roman');
        ylabel({'y [mm]'},'FontName','Times New Roman');
        zlabel({'t [s]'},'FontName','Times New Roman');
        %         view(3)
        %         daspect([1 1 0.01]);
        
        plot(expr_data(1:length(time),1,N),expr_data(1:length(time),2,N),'color', ct(exp,:),'LineWidth',2);
        
    end
end
plotObject3D([0 0 0],0,'k',0.1);
