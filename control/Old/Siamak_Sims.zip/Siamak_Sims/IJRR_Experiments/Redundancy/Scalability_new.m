clc; clear all; close all;

addpath('\\research.wpi.edu\srl\Projects\Ant\Delta_Rho\Motion capturing and communication\IJRR_Experiments\Scalability-500_500_20');

FailMode = [12 24 45];
FailTime = [2 2 2 ];
recoverTime = [35 35 35];

% RobotPopulation = [2 3 4 5];
% type = {'Decent'};
% extension = '500_500_20.mat';

lineType = {'-','--'};

cm = cool(length(FailMode));

figure(); hold on;
a1 = 0.5;
a0 = 0.1;
alpha = @(t,data) (a1-a0)/(data(end)-data(1))*(t-data(1))+a0;

t_max = [5 5 5 5];
figure(); hold on; axis equal;
for exp = 1 : length(FailMode)
    for itr = 1 : length(FailTime)
    clear expr_data expr_time
        fileName = sprintf('Fail_%d_%ds_%d',FailMode(exp),FailTime(exp),recoverTime(exp));
    load(fileName,'expr_data','expr_time');
    
        
        N = 5;
        
        grid on% box on
        time = expr_time(expr_time <= t_max(exp));
        ct = cool(length(FailMode));
        
            
            plotObject3D(expr_data(4,:,N),time(4),ct(exp,:),0.1);
       
        set(gca,'FontName','Times New Roman');
        xlabel({'x [mm]'},'FontName','Times New Roman');
        ylabel({'y [mm]'},'FontName','Times New Roman');
        zlabel({'t [s]'},'FontName','Times New Roman');
        view(3)
        daspect([1 1 0.01]);
                           
        plot3(expr_data(:,1,N),expr_data(:,2,N),zeros(size(expr_data(:,2,N))),'color',[0, 0.45, 0.74],'LineWidth',2);
       
    end
end

