clc; clear; close all;

addpath(genpath(sprintf('%s',pwd)));


delete(instrfind('Type', 'serial'));
BaudRate = 57600;
s1 = serial('COM6','BaudRate',BaudRate,'DataBits',8, 'StopBits',1);
fopen(s1);


dllPath = fullfile('Z:\OptiTrack\MATLAB Connection\NatNet_SDK_2.8\NatNetSDK\lib\x64\NatNetML.dll');
assemblyInfo = NET.addAssembly(dllPath);


theClient = NatNetML.NatNetClientML(0);

HostIP = char('130.215.48.201');
theClient.Initialize(HostIP, HostIP);
frameOfData = theClient.GetLastFrameOfData();

%%

Rz = @(q)[cosd(q) -sind(q) 0; sind(q) cosd(q) 0; 0 0 1];
x=[];
x_out = zeros(3,100);
f = zeros(3,100);

robot = struct('ID',1,'x',[],'xd',[],'in',[]);

stop = uicontrol('style','toggle','string','stop');


frameOfData = theClient.GetLastFrameOfData();
R = frameOfData.RigidBodies(1);

x_ = R.x;
y_ = R.y;
Q = [R.qw R.qx R.qy R.qz];
[q,~,~] = quaternions2euler(Q);
robot.xd = [x_*1000;y_*1000;q*57.2958];
robot.x = robot.xd;
% SerialCommunication(s1,robot,128,'xd');
% SerialCommunication(s1,robot,144,'x');



SerialCommunication(s1,robot,112);      % start

for i=1:3
    subplot(3,1,i); hold on
    fx_plot(i) = plot(1:100,zeros(1,100));
%     out_x_plot(i) = plot(1:100,zeros(1,100));
end



while(~get(stop,'value'));
    
    frameOfData = theClient.GetLastFrameOfData();
    R = frameOfData.RigidBodies(1);
    x_ = R.x;
    y_ = R.y;
    Q = [R.qw R.qx R.qy R.qz];
    [q,~,~] = quaternions2euler(Q);
    x(:,end+1) = [x_*1000;y_*1000;q*57.2958];
    robot.x = x(:,end);
    f(:,1:end-1) = f(:,2:end);
    f(:,end) =2*( Rz(x(3,end))'*(robot.xd - x(:,end)));
    f(3,end) = -f(3,end);
    robot.in=f(:,end);
    SerialCommunication(s1,robot,176,'in');
%     SerialCommunication(s1,robot,144,'x');
%     output = SerialCommunication(s1,robot,48);
%     
%     x_out(:,1:end-1) = x_out(:,2:end);
%     x_out(:,end) = output{1};
    
   
    
    
    for i=1:3
        set(fx_plot(i),'ydata',f(i,1:end));
%         set(out_x_plot(i),'ydata',x_out(i,1:end));
    end
    
    drawnow();
    
end

theClient.Uninitialize; % disconnect
theClient.delete;
fclose(s1);




