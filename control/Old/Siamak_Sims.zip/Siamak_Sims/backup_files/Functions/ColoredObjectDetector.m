function [objects] = ColoredObjectDetector(I,color)



diff_im = imsubtract(I(:,:,color), rgb2gray(I));

filt_im = medfilt2(diff_im, [3 3]);

bw_im = im2bw(filt_im,0.18);

area_im = bwareaopen(bw_im,10);

bw = logical(area_im);

objects = regionprops(bw, 'BoundingBox', 'Centroid');

 
    

end