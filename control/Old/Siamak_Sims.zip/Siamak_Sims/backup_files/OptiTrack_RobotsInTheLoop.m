clc; clear; close all;

addpath(genpath(sprintf('%s',pwd)));


delete(instrfind('Type', 'serial'));
BaudRate = 57600;
s1 = serial('COM6','BaudRate',BaudRate,'DataBits',8, 'StopBits',1);
fopen(s1);


% Add NatNet .NET assembly so that Matlab can access its methods, delegates, etc.
% Note : The NatNetML.DLL assembly depends on NatNet.dll, so make sure they
% are both in the same folder and/or path if you move them.
dllPath = fullfile('Z:\OptiTrack\MATLAB Connection\NatNet_SDK_2.8\NatNetSDK\lib\x64\NatNetML.dll');
assemblyInfo = NET.addAssembly(dllPath);


theClient = NatNetML.NatNetClientML(0); % Input = iConnectionType: 0 = Multicast, 1 = Unicast

% Connect to an OptiTrack server (e.g. Motive)
HostIP = char('130.215.48.201');
theClient.Initialize(HostIP, HostIP);

f1 = figure();
axis equal; hold on;
axis([-0.1 1.3 -0.1 1.3]);
grid on
stop = uicontrol('style','toggle','string','stop');
xlabel('x'); ylabel('y'); zlabel('z');

N = 3; % Number of robots ( I think, might be # Markers)
Q = [];

for i=1:N
    robot(i) = struct('ID',i,'x',[],'xd',[0;0;0]);
    arrow(i) = quiver(1,1,1,1,0,'MaxHeadSize',10,'LineWIdth',2);
end
% object = struct('ID','object','x',[]);
% arrow(4) = quiver(1,1,1,1,0,'MaxHeadSize',10,'LineWIdth',2,'color','b');


frameOfData = theClient.GetLastFrameOfData();

for i=1:3
    R = frameOfData.RigidBodies(i);
    x = R.x;
    y = R.y;
    Q = [R.qw R.qx R.qy R.qz];
    [q,~,~] = quaternions2euler(Q);
    robot(i).xd = [x*1000;y*1000;q*57.2958];
    
    SerialCommunication(s1,robot(i),128,'xd');
    u = 0.2*cos(q);
    v = 0.2*sin(q);
    set(arrow(i),'xdata',x,'ydata',y,'udata',u,'vdata',v);
    
end


SerialCommunication(s1,robot(1),112); % send start!
% SerialCommunication(s1,robot(2),112); % send start!
% SerialCommunication(s1,robot(3),112); % send start!




while(~get(stop,'value'))
    frameOfData = theClient.GetLastFrameOfData();
    
    % Get and Set robot information (robot.x
    for i=1:1
        R = frameOfData.RigidBodies(i);
        x = R.x;
        y = R.y;
        Q = [R.qw R.qx R.qy R.qz];
        [q,~,~] = quaternions2euler(Q);
        robot(i).x = [x*1000;y*1000;q*57.2958];
        
        SerialCommunication(s1,robot(i),144,'x'); % Send robot position
        u = 0.2*cos(q);
        v = 0.2*sin(q);
        set(arrow(i),'xdata',x,'ydata',y,'udata',u,'vdata',v);
        
    end
    % Get and Set Object information (object.x)
    %     O = frameOfData.RigidBodies(4);
    %     x = O.x;
    %     y = O.y;
    %     Q = [O.qw O.qx O.qy O.qz];
    %     [q,~,~] = quaternions2euler(Q);
    %     object.x = [x*1000;y*1000;q*57.2958];
    
    %     SerialCommunication(s1,object,160,'x'); % sending object poistion
    SerialCommunication(s1,robot,144,'x'); % sending robot positions
    %
    %     u = 0.2*cos(q);
    %     v = 0.2*sin(q);
    %     set(arrow(4),'xdata',x,'ydata',y,'udata',u,'vdata',v)
    
    %     output = SerialCommunication(s1,robot(1),48);
    %     disp('What we get:');
    %     disp(output{1})
    drawnow();
end

close(f1);

theClient.Uninitialize; % disconnect
theClient.delete;
fclose(s1);