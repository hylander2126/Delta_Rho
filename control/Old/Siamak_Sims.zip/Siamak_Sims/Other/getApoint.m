function getApoint(varargin)
global ready position aH x
pt = get(aH,'CurrentPoint');
if(ready == 0)
    position(1:2,1) = pt(1,1:2)';
    ready = 1;
else
    q = atan2(pt(1,2)-position(2), pt(1,1)-position(1));
    x = [position;q*57.2958];
    ready = 0;
end
end