clc; clear all; close all;

addpath('\\research.wpi.edu\srl\Projects\Ant\Delta_Rho\Motion capturing and communication\IJRR_Experiments\Redundancy');

% FailMode = [1 12 24 45 135];
% FailTime = [1 2 2 2 1];
% recoverTime = [15 35 35 35 50];


FailMode = [12 45 24];
FailTime = [2 2 2];
recoverTime = [35 35 35];


N = 5+1;

cm = parula(length(FailMode)+1);
%cm(end-1,:) = [0.9856    0.7372    0.2537];

a0 = 0.2;
a1 = 0.9;

alpha = @(t,data) (a1-a0)/(data(end)-data(1))*(t-data(1))+a0;

figure(); hold on;


for exp = 1 : length(FailMode)
    clear expr_data expr_time
    
    fileName = sprintf('Fail_%d_%ds_%d',FailMode(exp),FailTime(exp),recoverTime(exp));
    load(fileName,'expr_data','expr_time');
    
%     t = 1;
%     while(expr_time(t) <= 5)
%     %for t=1:5:length(expr_time)
%         plotObject(expr_data(t,:,N),cm(exp,:),0.1);%alpha(expr_time(t),expr_time)
%         t = t + 2;
%     end
    
    %plot(expr_data(:,1,N),expr_data(:,2,N),lineType{itr},'LineWidth',2,'color',cm(exp,:));
    
    
    %        subplot(1,length(RobotPopulation),exp); hold on; grid on; box on
    %        plot(expr_data(:,1,N),expr_data(:,2,N),lineType{itr},'LineWidth',2,'color',cm(exp,:));
    %        quiver(expr_data(1:5:end,1,N),expr_data(1:5:end,2,N),cos(expr_data(1:5:end,3,N)),sin(expr_data(1:5:end,3,N)),'color',cm(exp,:));
    %
    %
    %        axis equal
    %        axis([350 550 120 550]);
    
%     
    subplot(3,1,1); hold on;
    plot(expr_time,expr_data(:,1,N)-expr_data(1,1,N),'LineWidth',2,'color',cm(exp,:));
    %axis([1 6 -15 100]);
    
    subplot(3,1,2); hold on;
    plot(expr_time,expr_data(:,2,N)-expr_data(1,2,N),'LineWidth',2,'color',cm(exp,:));
    %axis([1 6 -15 250]);
    
    subplot(3,1,3); hold on;
    plot(expr_time,expr_data(:,3,N)-expr_data(1,3,N),'LineWidth',2,'color',cm(exp,:));
    %axis([1 6 -20 30]);
end

ylabels = {'x [mm]','y [mm]','\theta [{\circ}]'};
ylims = [0 150; 0 400; -20 30];
for n=1:3
    subplot(3,1,n);
    grid on; box on;
    set(gca,'FontName','Times New Roman');
    ylabel(ylabels{n},'FontName','Times New Roman');
    xlim([0 45]);
    ylim(ylims(n,:));
    plot([2 2],ylims(n,:),'-.r','LineWidth',1.5);
    plot([35 35],ylims(n,:),'-.r','LineWidth',1.5);
end
xlabel({'t [s]'},'FontName','Times New Roman');
subplot(3,1,3);
legend('1 and 2','4 and 5','2 and 4');


%plot(500,500,'+','MarkerSize',40,'color','r','LineWidth',2);

% axis equal
% axis([350 550 120 550]);
% grid on
% % legend('0g',weights{2:end})
% box on
% %
% set(gca,'FontName','Times New Roman');
% xlabel({'x [mm]'},'FontName','Times New Roman');
% ylabel({'y [mm]'},'FontName','Times New Roman');