clc; clear all; close all;


N = 3;
type = {'dect_'};
ext1 = 'form_';
ext2 = '_to_0_degree';
forms = {'060','080','120'};

lineType = {'-','--'};

cm = cool(length(forms)+1);

traj_comp = figure(); hold on;

w=[1 1 -0.3];
q= [0 0 660];

for exp = 1 : length(type)
    for itr = 1 : length(forms)
        clear expr_data expr_time
        fileName = [type{exp},ext1,forms{itr},ext2,'.mat'];
        load(fileName,'expr_data','expr_time');
        
        plot(w(itr)*expr_data(:,1,N+1)-500+q(itr),expr_data(:,2,N+1),...
            lineType{exp},'LineWidth',2,'color',cm(itr,:));
        
    end
end

plot(200,500,'+','MarkerSize',40,'color','r','LineWidth',2);

axis equal
axis([-50 300 -20 550]);
grid on
legend('90{\circ},150{\circ},210{\circ}',...
       '90{\circ},170{\circ},250{\circ}',...
       '90{\circ},210{\circ},330{\circ}')
box on

set(gca,'FontName','Times New Roman');
xlabel({'x [mm]'},'FontName','Times New Roman');
ylabel({'y [mm]'},'FontName','Times New Roman');