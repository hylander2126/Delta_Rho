function plotObject(x,color,alpha)

Q = 0:20:360;
r = 100;
R = 130;

fill(r*cosd(Q)+x(1),r*sind(Q)+x(2),color,'FaceAlpha',alpha,'EdgeColor',color);
plot(x(1)+[1 R*cosd(x(3))], x(2)+[1 R*sind(x(3))],'color','k');