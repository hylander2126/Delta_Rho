% function SceneDetection(vid,User)
function Scene  = SceneDetection(vid,User)


IM = getsnapshot(vid);
stop(vid);
flushdata(vid);



[M_IM,N_IM,~] = size(IM);


Scene.d_RG = 255;
Scene.d_RB = 255;
Scene.nPH = 0;
Scene.nPL = Inf;


if(~exist('User','var'))
    
    disp('Automated SceneDetection is under construction! Please use UI mode'); 
    
elseif(User)
    F = imshow(IM);
    axis image
    hold on
    title('Select Red markers by clicking on their opposite corners');
    xlabel('Press ESC to finish.');
    while(1)
        [x(1),y(1),button] = ginput(1);
        if(button == 3)
            break;
        end
        
        [x(2),y(2),button] = ginput(1);
        if(button == 3)
            break;
        end
        
        x = saturate(round(x), [1 N_IM]);
        y = saturate(round(y), [1 M_IM]);
        
        xl = min(x); xh = max(x);
        yl = min(y); yh = max(y);
        
        rectangle('Position',[xl,yl,xh-xl,yh-yl]);
        
        Marker = IM(yl:yh,xl:xh,:);
        
        Marker_ = medfilt2(imsubtract(Marker(:,:,1), rgb2gray(Marker)),[3 3]);
        Marker_ = im2bw(Marker_,0.05);
        Marker_ = bwareaopen(Marker_,10);
        Marker_ = logical(Marker_);
        
        [M,N] = size(Marker_);
        
        nP = 0;
        
        for m=1:M
            for n=1:N
                if(Marker_(m,n)==1)
                    
                    nP = nP + 1;
                    
                    RG = Marker(m,n,1) - Marker(m,n,2);
                    RB = Marker(m,n,1) - Marker(m,n,3);
                    
                    if(RG < Scene.d_RG)
                        Scene.d_RG = RG;
                    end
                    
                    if(RB < Scene.d_RB)
                        Scene.d_RB = RB;
                    end
                end     
            end
        end
        
        if(nP > Scene.nPH)
            Scene.nPH = nP;
        elseif( nP < Scene.nPL)
            Scene.nPL = nP;
        end
           
    end
        
        
    
    
end

start(vid);

end


function SaturatedValue = saturate(Value, Range)


[M,N] = size(Value);

SaturatedValue = zeros(M,N);


for m=1:M
    for n=1:N
        
        if ( Value(m,n) > Range(2) )
            SaturatedValue(m,n) = Range(2);
        elseif ( Value(m,n) < Range(1) )
            SaturatedValue(m,n) = Range(1);
        else
            SaturatedValue(m,n) = Value(m,n);
        end
        
    end
end

end

