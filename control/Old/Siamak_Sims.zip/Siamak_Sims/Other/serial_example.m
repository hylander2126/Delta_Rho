clc; clear; close;

delete(instrfind('Type', 'serial'));

BaudRate = 57600;


s1 = serial('COM4','BaudRate',BaudRate,'DataBits',8, 'StopBits',1); % Was /dev/tty.usbserial-DA01HMES
fopen(s1);


if(s1.BytesAvailable ~= 0)
    fread(s1,s1.BytesAvailable,'int8');
end


fwrite(s1,85, 'int8');
fwrite(s1,241, 'uint8');
%fwrite(s1,113, 'int8');

fwrite(s1,-1252, 'int16');
fwrite(s1,-666, 'int16');
fwrite(s1,-87, 'int16');


data = fread(s1,3,'int16');
disp(data);

fclose(s1);