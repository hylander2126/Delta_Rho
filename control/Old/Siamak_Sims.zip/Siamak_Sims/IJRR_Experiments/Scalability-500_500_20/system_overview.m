function system_overview
clc; close all;

Rz = @(q)[cosd(q) -sind(q);sind(q) cosd(q)];

fileName = '5_Sinewave_new';
load(fileName,'expr_data','expr_time');

figure();
hold on;


              
q = 0:1:360;

r = 30*ones(size(q));

Index = find( q==359);
subIndex = [];

for i = Index
  subIndex(end+1:end+3) = [i-1 i i+1];
end
r(subIndex) = 20;
Object = [r.*cosd(q);r.*sind(q)];


colors = lines(2);
alpha = 0.3;

for n = 1 : 20: size(expr_data,1)
    
    movedObject = Rz(expr_data(n,3,6))*Object;
    
    fill(movedObject(1,:)+expr_data(n,1,4),movedObject(2,:)+expr_data(n,2,4),...
        colors(1,:),'FaceAlpha',0.1);
    hold on
    
    axis equal
    %axis([0 100 0 750]);
    drawnow();
    %hold off;

end

grid on
set(gca,'FontName','Times New Roman')
box on
end





