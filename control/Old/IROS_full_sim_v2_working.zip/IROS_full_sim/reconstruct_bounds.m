%% RECONSTRUCT BOUNDS USING systemDynamics CALL - DOESN'T WORK BUT IS CLEANER THAN *GLOBAL* CALL

% Reset all relevant properties for accurate representation
O.prev_theta = po_0(3);
O.move(po_0,dpo_0);

for i=1:N
    A(i).move([aPoints(i,:) pi+qq(i)],pd,O);
    A(i).theta_meas_prev = O.p(3);
    A(i).desired_direc = [-1;0];
    A(i).stop = 0;
    A(i).measure_t = 0;
    A(i).theta_meas_prev = 0;
    A(i).negBound = negBound; % Reset initial bounds
    A(i).posBound = posBound;
end

bounds = zeros([length(t),4]); 
desired_direction = zeros([length(t),2]);

for n=1:length(tspan)
    [~, bounds(n,:), desired_direction(n,:)] = systemDynamics(t(n), y(n,:), pd, A, O, Q);
end