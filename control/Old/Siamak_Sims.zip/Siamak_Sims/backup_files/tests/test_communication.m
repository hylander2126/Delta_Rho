clc; clear; close all;

addpath(genpath(sprintf('%s',pwd)));


delete(instrfind('Type', 'serial'));
BaudRate = 57600;
s1 = serial('COM6','BaudRate',BaudRate,'DataBits',8, 'StopBits',1);
fopen(s1);


dllPath = fullfile('Z:\OptiTrack\MATLAB Connection\NatNet_SDK_2.8\NatNetSDK\lib\x64\NatNetML.dll');
assemblyInfo = NET.addAssembly(dllPath);


theClient = NatNetML.NatNetClientML(0);

HostIP = char('130.215.48.201');
theClient.Initialize(HostIP, HostIP);
frameOfData = theClient.GetLastFrameOfData();
t=0;
time=[];
x=[];
x_out=[];
 robot = struct('ID',1,'x',[1;1;0],'xd',[500;500;0]);

stop = uicontrol('style','toggle','string','stop');

while(~get(stop,'value'));
 
    frameOfData = theClient.GetLastFrameOfData();
    R = frameOfData.RigidBodies(1);
   
    x_ = R.x;
    y_ = R.y;
    Q = [R.qw R.qx R.qy R.qz];
    [q,~,~] = quaternions2euler(Q);
    x(:,end+1) = [x_*1000;y_*1000;q*57.2958];
    robot.x = x(:,end);
    SerialCommunication(s1,robot,144,'x');
    output = SerialCommunication(s1,robot,48,'Out');
    x_out(:,end+1) = output{1};

    subplot(2,1,1);
    plot(x');
    
    subplot(2,1,2);
    plot(x_out');

    drawnow();
    
end
       
theClient.Uninitialize; % disconnect
theClient.delete;
fclose(s1);