function [varargout] = plotv(x,y,v,varargin)

P.LineColor = [0, 0.4470, 0.7410];
P.FaceColor = [0, 0.4470, 0.7410];
P.FaceAlpha = 0.5;
P.EdgeColor = [0, 0.4470, 0.7410];
P.EdgeWidth = 0.5;
P.LineWidth = 0.5;

nargin 
if nargin < 3
    error('Not enough input arguments.');
else
    for n=4:2:nargin
        P.(varargin{n-3}) = varargin{n-2};
    end
end



varargout{1} = fill([x fliplr(x)],[y fliplr(y+v)],P.FaceColor,...
                    'FaceAlpha',P.FaceAlpha,...
                    'EdgeColor',P.EdgeColor,...
                    'LineWidth',P.EdgeWidth);
hold on
varargout{2} = plot(x,y,'color',P.LineColor,'LineWidth',P.LineWidth);

