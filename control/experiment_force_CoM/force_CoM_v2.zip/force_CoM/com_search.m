function new_direction = com_search(d,f,Robot)

    direc = d;
    prev_x = Robot.prev_direc(1);
    prev_y = Robot.prev_direc(2);

    e = -atan2d(direc(1)*prev_y - direc(2)*prev_x, direc(1)*prev_x + direc(2)*prev_y);
    de = -rad2deg(0); %O.dp(3));

    phi = 1.1*e + 1*de;
    new_direction = Rz2(deg2rad(phi)) * Robot.prev_direc;

end