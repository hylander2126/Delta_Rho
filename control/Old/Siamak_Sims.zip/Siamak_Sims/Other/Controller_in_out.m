clc; clear; close;


X = [0; 1; 0];
Kp = 1000;


X(3) = X(3)*pi/180;


f = @(ex,ey,eq,q) 3*[ eq/3 - ex*(sin(q)/3 + (3^(1/2)*cos(q))/3) + ey*(cos(q)/3 - (3^(1/2)*sin(q))/3);
    eq/3 - (2*ey*cos(q))/3 + (2*ex*sin(q))/3;
    eq/3 - ex*(sin(q)/3 - (3^(1/2)*cos(q))/3) + ey*(cos(q)/3 + (3^(1/2)*sin(q))/3)];


F = f(-X(1),-X(2),-X(3),X(3));
 
u = zeros(6,1);

for n=1:3
    if(F(n,end) >= 0)
        u(2*n) = uint8(Kp*abs(F(n,end)));
        
    else
        u(2*n-1) = uint8(Kp*abs(F(n,end)));
    end
end

fprintf('============== \n F = : \n');
disp(F);
fprintf('============== \n u = : \n');
disp(u);
