function R = Rz2(q)

R = [cos(q),-sin(q);sin(q),cos(q)];

end