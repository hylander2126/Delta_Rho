function [shapes]=showObject(figHandle,shapes,x)

if(nargin > 1)
    
    position = shapes.body.data;
    
    R = [cos(x(3)) -sin(x(3)); sin(x(3)) cos(x(3))];

    newPositions = x(1:2)*ones(1,length(position)) +  R*position;
    
    set(shapes.body.handle,'xdata',newPositions(1,:),'ydata',newPositions(2,:));
    
    
    s = shapes.coordinate.size;
    newVec = R*[s 0;0 s];
    
    set(shapes.coordinate.handle,'xdata',[x(1) x(1)],'ydata',[x(2) x(2)]); 
    set(shapes.coordinate.handle,'udata',newVec(1,:),'vdata',newVec(2,:));
    
else
    figure(figHandle);
    hold on
    
    % Constructing Object Shape
    
    q = 0:10:360;
    
    r = 50*ones(size(q));
    
    Index = find(q==60 | q==180 | q == 300);
    subIndex = [];
    
    for i = Index
        subIndex(end+1:end+3) = [i-1 i i+1];
    end
    
    r(subIndex) = 100;
    
    xObject = r.*cosd(q);
    yObject = r.*sind(q);
    
    ObjectHandle = fill(xObject,yObject,'b');
    
    % Constructing Coordinate system
    s = 100;
    coordinateHandle = quiver([0 0],[0 0],[s 0],[0 s],0);
    
    % Structure
    shapes.body.data = [xObject;yObject];
    shapes.body.handle = ObjectHandle;
    
    shapes.coordinate.size = s;
    shapes.coordinate.handle = coordinateHandle;
    
end