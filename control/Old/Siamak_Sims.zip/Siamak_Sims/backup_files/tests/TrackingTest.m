clc; clear; close all;

addpath(genpath(sprintf('%s',pwd)));


load('matlab.mat');


S = [];
robot = struct('ID',[],'x',[],'xd',[],'Detectors',[],'x0',[],'color',[]);
markers = struct('d_RG',45,'d_RB',45,'nPL',100,'nPH',400);
tracking = struct('t',0,'MLF',-2,'R',50);
settings = struct('n',1.2,'eps',20,'offset',[sqrt(2^2-1)/2;0;pi]);

f1 = figure();


frames = 1:length(M);



for n=frames
    %IM = M(n).cdata(95:200,200:400,:);
    IM = M(n).cdata;
    imshow(IM);
    
    objects = RedObjectDetector(IM,markers);
    
    if(isempty(objects))
        drawnow();
        %pause();
        continue
    end
    
    C = ExtractCentriod(objects);
    
    
    [S,P] = ObjectTracking(C,S,0,tracking.MLF,tracking.R);
    
%     robot = RobotTracking(robot,S,settings);
%     
%     hold on
%     if(~isempty(robot))
%         for i=1:length(robot)
%             x = robot(i).x(1); y = robot(i).x(2);
%             u = 20*cos(robot(i).x(3));
%             v = 20*sin(robot(i).x(3));
%             quiver(x,y,u,v,'LineWidth',2,'MaxHeadSize',5);
%         end
%     end
            
    
    PlotInfo(f1,C,S,P,tracking.R);
    
    drawnow();
    %pause();
end