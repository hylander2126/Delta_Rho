
% Rot matrix fn
Rz = @(th) [cos(th), -sin(th); sin(th), cos(th)];

theta1 = deg2rad(120);
theta2 = deg2rad(60); % THIS IS ACTUALLY AN EXTERIOR ANGLE

% Interior angles of five-bar
q = zeros([5,1]);
q(1) = rad2deg(theta1);
q(5) = rad2deg(theta2);

%% Define problem constraints
% Spring constant calculation
maxTorque = 0.402; % in-lb
maxDeflection = pi; % 180 degrees

maxTorque = maxTorque * (25.4/1) * (4.448/1); % Convert in-lb to N-mm
k = maxTorque/maxDeflection; % N-mm/rad

% Define link lengths
l1 = 25;
l2 = 40;
l3 = 40;
l4 = 25;
l5 = 22.84;

% First and Last point coordinates
A = [0; 0];
E = [l5; 0];

%% Calculate coordinates of all other joints
% Coordinates of joint 2 and 4
B = [l1*cos(theta1) ; l1*sin(theta1)];
D = [l5 + l4*cos(theta2) ; l4*sin(theta2)];

% Get distance between joints 2 and 4
d = norm(D-B);

%% Now use law of cosines to determine angles between links. THIS ONLY WORKS BECAUSE L1 AND L4 SYMMETRIC IN BASE CONFIG
% Apex angle b/w l2 and l3
q(3) = rad2deg(acos(1-(d^2/(2*l2^2))));
% Base angles of 'upper triangle' created by d
b = ((180 - q(3))/2);

% Now add remaining angle from beneath upper triangle
q(2) = 180 - q(1) + b;
q(4) = q(5) + b;


%% Calculate angle between d and l2
alpha = acos((l2.^2 + d.^2 - l3.^2)./(2*l2.*d));
rad2deg(alpha)

% Get "V" vector with length l2 along d
v = l2*(D - B)./d;

% Calculate end effector x,y by rotating V vector by alpha (rot. matrix)
C = Rz(alpha) * v + B;
