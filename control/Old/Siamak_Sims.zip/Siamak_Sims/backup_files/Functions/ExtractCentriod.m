function [C] = ExtractCentriod(objects)

C = zeros(2,length(objects));
for i=1:length(objects)
    C(:,i) = objects(i).Centroid';
end