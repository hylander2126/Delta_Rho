function [] = Robot_Remote_Control()

    clc; clear; close all;
    
    global robot n N exit K u_r
    
    N = 6; % Number of robots
    exit = 0;
    K = 80;
    n = 2;
    u_r = [0;0;0];
    
    figure('KeyPressFcn',@getKey) ;
    
    addpath(genpath(sprintf('%s',pwd)));
    
    delete(instrfind('Type', 'serial'));
    s1 = serialport('COM4', 9600, 'DataBits', 8, 'StopBits', 1);
%     s1 = serialport('/dev/tty.usbserial-DA01HMES',BaudRate,'DataBits',8, 'StopBits',1);
    fopen(s1);
    
    % Initialize robot properties for all robots 1:N
    for i=1:N
        robot(i).ID = i;
        robot(i).u.data = zeros(6,1); 
        robot(i).u.type = 'uint8';
        robot(i).u.convertor = @(x)uint8(x);
    end
    
    drawnow();
    
    % Send info to each robot via serial comms.
    while(~exit)
        pause(0.1);
        for i=1:N
            % Send actuator command (192) to robot i containing data 'robot.u'
            SerialCommunication(s1,robot(i),192,'u');
        end
    end

    for i=1:N
        robot(i).u.data = zeros(6,1);
        SerialCommunication(s1,robot(i),192,'u');
    end
    fclose(s1);
end

function getKey(~, event)
    global robot n N exit K u_r
    
    map = 1; % Turn on if you want to control
    c = event.Key;
    %% Method to change robot we are controlling - I ELIMINATED THIS
    number = str2num(c);
    if(~isempty(number))
        if(number <= N  && number > 0)
            robot(n).u.data = zeros(6,1);
            n = number;
            fprintf('Changing robot to #%d\n',number);
        end
    end
    %%

    switch(c)
        case 'leftarrow'
            u_r = [0;-K;0];
        case 'rightarrow'
            u_r = [0;K;0];
        case 'uparrow'
            u_r = [K;0;0];
        case 'downarrow'
            u_r = [-K;0;0];
        case 'z'
            u_r = [0;0;K];
        case 'x'
            u_r = [0;0;-K];
        case 's'    
            u_r = [0;0;0];
        case 'hyphen'
            K = K - 1;
            if(K < 1)
                K = 0;
            end
            u_r(u_r ~= 0) = K;
            fprintf('K changed to %d \n',K);
        case 'equal'
            K = K + 1;
            fprintf('K changed to %d \n',K);
            u_r(u_r ~= 0) = K;
        case 'escape'
            fprintf('Exiting control...\n');
            exit = 1;
    end
    
    if(map == 1)
        temp = [1.7322, 1, 1;
                0, -2, 1;
                -1.7322, 1, 1];
        f = temp*u_r;
        for k=1:3 % Loop through f ~ motor values [front L, rear, front R]'
            for n=1:N % Loop through each robot
                if(f(k) >= 0) % Set positive registry to our gain
                    robot(n).u.data(2*k-1,1) = 0;
                    robot(n).u.data(2*k,1) = uint8(abs(f(k)));
                else
                    robot(n).u.data(2*k-1,1) = uint8(abs(f(k)));
                    robot(n).u.data(2*k,1) = 0;
                end
            end
        end

%     %% TEMP FOR MIRRORING MAIN ROBOT
%     f = pinv(temp)*u_r;
%     for k=1:3
%         if(f(k) >= 0)
%             robot(4).u.data(2*k-1,1) = 0;
%             robot(4).u.data(2*k,1) = uint8(abs(f(k)));
%         else
%             robot(4).u.data(2*k-1,1) = uint8(abs(f(k)));
%             robot(4).u.data(2*k,1) = 0;
%         end
%     end
    end

end