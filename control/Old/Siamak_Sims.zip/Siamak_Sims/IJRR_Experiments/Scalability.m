% clc; clear all; close all;

addpath('\\research.wpi.edu\srl\Projects\Ant\Delta_Rho\Motion capturing and communication\IJRR_Experiments\Scalability-500_500_20');

RobotPopulation = [4 5];
type = {'cent'};
extension = '500_500_20.mat';

lineType = {'-','--'};

cm = cool(length(RobotPopulation));
% cm(end-1,:) = [0.9856    0.7372    0.2537];

traj_comp = figure(); hold on;


for exp = 1 : length(RobotPopulation)
    for itr = 1 : length(type)
        clear expr_data expr_time
        fileName = sprintf('%d_%s_%s',RobotPopulation(exp),type{itr},extension);
        load(fileName,'expr_data','expr_time');
        
        N = RobotPopulation(exp)+1;
        
        
        %plot(expr_data(:,1,N),expr_data(:,2,N),lineType{itr},'LineWidth',2,'color',cm(exp,:));

       
%        subplot(1,length(RobotPopulation),exp); hold on; grid on; box on
%        plot(expr_data(:,1,N),expr_data(:,2,N),lineType{itr},'LineWidth',2,'color',cm(exp,:));
%        quiver(expr_data(1:5:end,1,N),expr_data(1:5:end,2,N),cos(expr_data(1:5:end,3,N)),sin(expr_data(1:5:end,3,N)),'color',cm(exp,:));
%        
%        
%        axis equal
%        axis([350 550 120 550]);
       
        
        subplot(3,1,1); hold on;
        plot(expr_time,expr_data(:,1,N),lineType{itr},'LineWidth',2,'color',cm(exp,:));
        axis([0 8 350 550]);
        
        subplot(3,1,2); hold on;
        plot(expr_time,expr_data(:,2,N),lineType{itr},'LineWidth',2,'color',cm(exp,:));
        axis([0 8 150 550]);
        
        subplot(3,1,3); hold on;
        plot(expr_time,expr_data(:,3,N),lineType{itr},'LineWidth',2,'color',cm(exp,:));
        axis([0 8 -10 30]);
    end
end

ylabels = {'x [mm]','y [mm]','{\theta} [{\circ}]'};
for n=1:3
    subplot(3,1,n);
    grid on; box on;
    set(gca,'FontName','Times New Roman');
    ylabel(ylabels{n},'FontName','Times New Roman');
%     plot([1 6],[0 0],'-.r','LineWidth',1.5);
end
% xlabel({'t [s]'},'FontName','Times New Roman');
% subplot(3,1,1);
% legend('2','3','4','5');


%plot(500,500,'+','MarkerSize',40,'color','r','LineWidth',2);

% axis equal
% axis([350 550 120 550]);
% grid on
% % legend('0g',weights{2:end})
% box on
% % 
% set(gca,'FontName','Times New Roman');
% xlabel({'x [mm]'},'FontName','Times New Roman');
% ylabel({'y [mm]'},'FontName','Times New Roman');