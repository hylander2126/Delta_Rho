clc; clear all; close all;


N = 3;
type = {'dect_','cent_'};
ext1 = 'form_';
ext2 = '_to_0_degree';
forms = {'060','080','120'};

lineType = {'-','--'};

cm = parula(length(forms)+1);

traj_comp = figure(); hold on;

q_offset = [0 0 -120];
for exp = 1 : length(type)
    for itr = 1 : length(forms)
        clear expr_data expr_time
        fileName = [type{exp},ext1,forms{itr},ext2,'.mat'];
        load(fileName,'expr_data','expr_time');
        
        
        subplot(3,1,1); hold on
        plot(expr_time,expr_data(:,1,N+1)-500,...
            lineType{exp},'LineWidth',1.5,'color',cm(itr,:));
        
        subplot(3,1,2); hold on
        plot(expr_time,expr_data(:,2,N+1),...
            lineType{exp},'LineWidth',1.5,'color',cm(itr,:));
        
        subplot(3,1,3); hold on
        plot(expr_time,expr_data(:,3,N+1)+q_offset(itr),...
            lineType{exp},'LineWidth',1.5,'color',cm(itr,:));
        
    end
end

labels = {'x','y','\theta'};
xd = [200 500 0];
ylims = [-20 300 ; 0 550; -100 70];

for i=1:3
    subplot(3,1,i)
    plot([0 10],[xd(i) xd(i)],'-.r','lineWidth',1.5);
    xlim([0 8]);
    ylim(ylims(i,:));
    grid on
    box on
    %axis([-50 300 -20 550]);
    set(gca,'FontSize',16,'FontName','Times New Roman');
    ylabel({[labels{i},' [mm]']},'FontName','Times New Roman');
end
legend('90{\circ},150{\circ},210{\circ}',...
       '90{\circ},170{\circ},250{\circ}',...
       '90{\circ},210{\circ},330{\circ}')

xlabel({'t [s]'},'FontName','Times New Roman');
