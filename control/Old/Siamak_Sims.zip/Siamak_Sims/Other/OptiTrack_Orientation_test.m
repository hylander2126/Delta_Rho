clc; clear; close all;

addpath(genpath(sprintf('%s',pwd)));


% Add NatNet .NET assembly so that Matlab can access its methods, delegates, etc.
% Note : The NatNetML.DLL assembly depends on NatNet.dll, so make sure they
% are both in the same folder and/or path if you move them.
dllPath = fullfile('\\research.wpi.edu\srl\OptiTrack\MATLAB Connection\NatNet_SDK_2.8\NatNetSDK\lib\x64\NatNetML.dll');
assemblyInfo = NET.addAssembly(dllPath);

theClient = NatNetML.NatNetClientML(0); % Input = iConnectionType: 0 = Multicast, 1 = Unicast

% Connect to an OptiTrack server (e.g. Motive)
HostIP = char('130.215.48.201');
theClient.Initialize(HostIP, HostIP);

f1 = figure(); axis equal; hold on; axis([-0.1 1.3 -0.1 1.3 -0.1 1.3]);
grid on;
hold on;
stop = uicontrol('style','toggle','string','stop');
xaxis = quiver3(1,1,1,0,0,0,0,'MaxHeadSize',20,'LineWIdth',3,'color','r');
yaxis = quiver3(1,1,1,0,0,0,0,'MaxHeadSize',20,'LineWIdth',3,'color','g');
zaxis = quiver3(1,1,1,0,0,0,0,'MaxHeadSize',20,'LineWIdth',3,'color','b');

x_onplane = quiver(1,1,0,0,0,'MaxHeadSize',20,'LineWIdth',3,'color','c');

xlabel('x'); ylabel('y'); zlabel('z');
view(3);
grid on



while(~get(stop,'value'))
    frameOfData = theClient.GetLastFrameOfData();
    
    R = frameOfData.RigidBodies(1);
    x = R.x;
    y = R.y;
    z = R.z;
    
    Q(1) = R.qw;
    Q(2) = R.qx;
    Q(3) = R.qy;
    Q(4) = R.qz;
  
    Rotation = quaternions2R(Q);
    
    dx = Rotation*[0.2;0;0];
    dy = Rotation*[0;0.2;0];
    dz = Rotation*[0;0;0.2];
    
    
    [q,~,~] = quaternions2euler(Q);
    
    
    
    %set(robotPlot,'xdata',x,'ydata',y,'zdata',z);
    set(xaxis,'xdata',x,'ydata',y,'zdata',z,'udata',dx(1),'vdata',dx(2),'wdata',dx(3));
    set(yaxis,'xdata',x,'ydata',y,'zdata',z,'udata',dy(1),'vdata',dy(2),'wdata',dy(3));
    set(zaxis,'xdata',x,'ydata',y,'zdata',z,'udata',dz(1),'vdata',dz(2),'wdata',dz(3));
    set(x_onplane,'xdata',x,'ydata',y,'udata',0.2*cos(q),'vdata',0.2*sin(q));
    
    drawnow();
end

close(f1);

theClient.Uninitialize; % disconnect
theClient.delete;