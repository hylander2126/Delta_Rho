function varargout = video_input(varargin)
% VIDEO_INPUT MATLAB code for video_input.fig
%      VIDEO_INPUT, by itself, creates a new VIDEO_INPUT or raises the existing
%      singleton*.
%
%      H = VIDEO_INPUT returns the handle to a new VIDEO_INPUT or the handle to
%      the existing singleton*.
%
%      VIDEO_INPUT('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in VIDEO_INPUT.M with the given input arguments.
%
%      VIDEO_INPUT('Property','Value',...) creates a new VIDEO_INPUT or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before video_input_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to video_input_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help video_input

% Last Modified by GUIDE v2.5 18-Sep-2015 17:32:04

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
    'gui_Singleton',  gui_Singleton, ...
    'gui_OpeningFcn', @video_input_OpeningFcn, ...
    'gui_OutputFcn',  @video_input_OutputFcn, ...
    'gui_LayoutFcn',  [] , ...
    'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before video_input is made visible.
function video_input_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to video_input (see VARARGIN)

clc;
handles.output_properties = [];

set(handles.vid_disp,'Visible','off');
set(handles.Properties_panel,'Visible','off');

pos = get(handles.System_Status_Pannel,'Position');
pos(2) = 42;
set(handles.System_Status_Pannel,'Position',pos);
handles.video_paly = 0;
handles.message{1} = 'Initializing...';
handles.info_main = imaqhwinfo;
handles.adaptor = 0;
set(handles.vid_adaptor,'String',handles.info_main.InstalledAdaptors)
handles.message = update_message(handles.message,'Initialization completed.',handles.sysMessage);

% Choose default command line output for video_input
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes video_input wait for user response (see UIRESUME)
uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = video_input_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output_properties;
delete(handles.figure1);

% --- Executes on selection change in vid_adaptor.
function vid_adaptor_Callback(hObject, eventdata, handles)
% hObject    handle to vid_adaptor (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns vid_adaptor contents as cell array
%        contents{get(hObject,'Value')} returns selected item from vid_adaptor


handles.adaptor = handles.info_main.InstalledAdaptors{get(hObject,'Value')};
handles.info_2 = imaqhwinfo(handles.adaptor);
list = handles.info_2.DeviceIDs;
if(isempty(list))
    list = '- Empty -';
end
set(handles.device_ID,'String',list);

if(length(list)==1)
    
    message = 'Selected adaptor has only one ID.';
    handles.message = update_message(handles.message,message,handles.sysMessage);
    message = 'Device ID = 1 is selected as the active ID.';
    handles.message = update_message(handles.message,message,handles.sysMessage);
    
    handles.ID = 1;
    handles.info_3 = imaqhwinfo(handles.adaptor,handles.ID);
    handles.formats_list = handles.info_3.SupportedFormats;
    set(handles.vid_format,'String',handles.formats_list);
end

guidata(hObject, handles);

% --- Executes during object creation, after setting all properties_panel.
function vid_adaptor_CreateFcn(hObject, eventdata, handles)
% hObject    handle to vid_adaptor (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in device_ID.
function device_ID_Callback(hObject, eventdata, handles)
% hObject    handle to device_ID (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns device_ID contents as cell array
%        contents{get(hObject,'Value')} returns selected item from device_ID


handles.ID = cell2mat(handles.info_2.DeviceIDs(get(hObject,'Value')));
handles.info_3 = imaqhwinfo(handles.adaptor,handles.ID);
handles.formats_list = handles.info_3.SupportedFormats;
set(handles.vid_format,'String',handles.formats_list);
message = sprintf('Device ID = %d is selected as the active ID.',handles.ID);
handles.message = update_message(handles.message,message,handles.sysMessage);

guidata(hObject, handles);


% --- Executes during object creation, after setting all properties_panel.
function device_ID_CreateFcn(hObject, eventdata, handles)
% hObject    handle to device_ID (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in vid_format.
function vid_format_Callback(hObject, eventdata, handles)
% hObject    handle to vid_format (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns vid_format contents as cell array
%        contents{get(hObject,'Value')} returns selected item from vid_format

handles.format = handles.info_3.SupportedFormats{get(hObject,'Value')};

message = sprintf('Device format changed to %s',handles.format);
handles.message = update_message(handles.message,message,handles.sysMessage);

if(handles.video_paly)
    
    message = 'Restarting video...';
    handles.message = update_message(handles.message,message,handles.sysMessage);
    stoppreview(handles.vid);
    
    message = 'Generating new video input...';
    handles.message = update_message(handles.message,message,handles.sysMessage);
    
    drawnow();
    
    handles.vid = videoinput(handles.adaptor, handles.ID,handles.format);
    handles.src = getselectedsource(handles.vid); 
    handles.vid.FramesPerTrigger = Inf;
    vidRes = handles.vid.VideoResolution;
    nBands = handles.vid.NumberOfBands;
    hImage = image( zeros(vidRes(2), vidRes(1), nBands) );
    preview(handles.vid, hImage);
    message = sprintf('Video started on %s format',handles.format);
    handles.message = update_message(handles.message,message,handles.sysMessage);
end

guidata(hObject, handles);



% --- Executes during object creation, after setting all properties_panel.
function vid_format_CreateFcn(hObject, eventdata, handles)
% hObject    handle to vid_format (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in Start_vid.
function Start_vid_Callback(hObject, eventdata, handles)
% hObject    handle to Start_vid (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

handles.format = handles.info_3.SupportedFormats{get(handles.vid_format,'Value')};
if(~handles.video_paly)
    
    pos = get(handles.System_Status_Pannel,'Position'); 
    pos(2) = 0.5385;
    set(handles.System_Status_Pannel,'Position',pos);
    message = 'Generating new video input...';
    handles.message = update_message(handles.message,message,handles.sysMessage);
    drawnow();
    handles.vid = videoinput(handles.adaptor, handles.ID,handles.format);
    handles.src = getselectedsource(handles.vid);
    handles.vid.FramesPerTrigger = Inf;
    set(handles.vid_disp,'Visible','on');
    
    
    vidRes = handles.vid.VideoResolution;
    nBands = handles.vid.NumberOfBands;
    handles.vid_disp = image( zeros(vidRes(2), vidRes(1), nBands) );
    preview(handles.vid, handles.vid_disp);
    set(handles.Properties_panel,'Visible','on');
    
    message = sprintf('Video started on %s format',handles.format);
    handles.message = update_message(handles.message,message,handles.sysMessage);

    %======================================================================
    message = 'Acquiring device properties...';
    handles.message = update_message(handles.message,message,handles.sysMessage);
    drawnow();
    handles.prop_info = propinfo(handles.src);
    handles.property_list = fieldnames(handles.prop_info);
    handles.nProp = length(handles.property_list);
    handles.propType = [];
    k = 0;
    handles.validProps = [];
    for i=1:handles.nProp
        property = handles.prop_info.(handles.property_list{i});
        
        ReadOnly = property.ReadOnly;
        
        if(~strcmp(ReadOnly,'whileRunning'))
            continue;
        end
        
        Y = 750 - 28*k; k = k+1;
        
        
        values = property.ConstraintValue;
        
        handles.validProps(end+1) = i;
        
        if(iscellstr(values))
            handles.propType(i) = 2; % Cell array property
            handles.prop_default{i} = property.DefaultValue; 
            string = handles.property_list{i};
            handles.prop(i) = uicontrol(gcf,'Style', 'popup','String', values,...
                'Position', [890 Y 70 50],'Callback',@p_Callback);
        elseif(isnumeric(values))
            handles.propType(i) = 1; % Numeric property
            handles.prop_default{i} = num2str(property.DefaultValue);
            string = sprintf('%s [%d , %d]',handles.property_list{i},values);
            handles.prop(i) = uicontrol(gcf,'Style', 'edit','String',num2str(property.DefaultValue),...
                'Position', [890 Y+27 50 20],'Callback',@p_Callback);
        end

        uicontrol(gcf,'Style','text','String',string,...
                'fontsize',8,'Position',[760 Y+15 130 30],...
                'HorizontalAlignment','left');        
    end

    message = 'Device properties list completed.';
    handles.message = update_message(handles.message,message,handles.sysMessage);

end
handles.video_paly  = 1;
guidata(hObject, handles);



% --- Executes on button press in Stop_vid.
function Stop_vid_Callback(hObject, eventdata, handles)
% hObject    handle to Stop_vid (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

if(handles.video_paly)
    stoppreview(handles.vid);
    handles.video_paly = 0;
end

guidata(hObject, handles);

% --- Executes on button press in Restore_default.
function Restore_default_Callback(hObject, eventdata, handles)
% hObject    handle to Restore_default (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

message = 'Restoring default properties...';
handles.message = update_message(handles.message,message,handles.sysMessage);

for i=1:handles.nProp
      switch (handles.propType(i))
          case (1)
              set(handles.prop(i),'String',handles.prop_default{i});
              handles.src.(handles.property_list{i}) = str2double(handles.prop_default{i});
          case (2)
              list = get(handles.prop(i),'String');
              for j=1:length(list)
                  if(strcmp(list{j},handles.prop_default{i}))
                      set(handles.prop(i),'value',j);
                      break
                  end
              end
              handles.src.(handles.property_list{i}) = handles.prop_default{i};
      end
end

message = 'View updated.';
handles.message = update_message(handles.message,message,handles.sysMessage);

guidata(hObject, handles);

% --- Executes on button press in Export.
function Export_Callback(hObject, eventdata, handles)
% hObject    handle to Export (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

handles.output_properties.adaptor = handles.adaptor;
handles.output_properties.ID = handles.ID;
handles.output_properties.format = handles.format;

for n = handles.validProps
    handles.output_properties.(handles.property_list{n}) = handles.src.(handles.property_list{n});
end

guidata(hObject, handles);
close(handles.figure1);


function p_Callback(hObject,eventdata)
  handles = guidata(gcbf);  % This gets the handles structure from the figure
  
  message = 'Updating view...';
    handles.message = update_message(handles.message,message,handles.sysMessage);
  
  for i=1:handles.nProp
      switch (handles.propType(i))
          case (1)
              handles.src.(handles.property_list{i}) = str2double(get(handles.prop(i),'String'));
          case (2)
              list = get(handles.prop(i),'String'); 
              val = get(handles.prop(i),'value');
              str = list{val};
              handles.src.(handles.property_list{i}) = str;
      end
  end
   
  message = 'View updated.';
  handles.message = update_message(handles.message,message,handles.sysMessage);
  
  
  guidata(gcbf,handles);  % This is needed if the handles structure is modified


function message = update_message(message,newInfo,textBox)
    message{end+1} = newInfo;
    if(length(message) > 17)
        temp = message(2:end);
        message = temp;
    end
    
    set(textBox,'String',message);

    


% --- Executes during object creation, after setting all properties_panel.
function sysMessage_CreateFcn(hObject, eventdata, handles)
% hObject    handle to sysMessage (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties_panel.
function vid_disp_CreateFcn(hObject, eventdata, handles)
% hObject    handle to vid_disp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: place code in OpeningFcn to populate vid_disp


% --- Executes during object creation, after setting all properties_panel.
function System_Status_Pannel_CreateFcn(hObject, eventdata, handles)
% hObject    handle to System_Status_Pannel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes on button press in pushbutton5.
function pushbutton5_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in Update_properties.
function Update_properties_Callback(hObject, eventdata, handles)
% hObject    handle to Update_properties (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes during object creation, after setting all properties_panel.
function Properties_panel_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Properties_panel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes when user attempts to close figure1.
function figure1_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

if isequal(get(hObject, 'waitstatus'), 'waiting')
% The GUI is still in UIWAIT, us UIRESUME
uiresume(hObject);
else
% The GUI is no longer waiting, just close it
delete(hObject);
end
