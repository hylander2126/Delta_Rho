% Author: Steven M Hyland
% Date: 02/16/2023
% Copyright @ Steven M Hyland. All rights reserved

%% Got attachment process and manipulation process working. Agents avoid payload when connecting. Now working on single
% agent CoM estimation (like for ICRA)

clc; clear; close all;
addpath('classes and functions');

%% Problem definition
N = 1;            % Team population
pd = [1; 1; pi];  % Desired point [x;y;q] in m

po_0 = [0; 0; 0]; % Initial position of the object
dpo_0 = [0;0;0];  % Initial velocity of the object

tspan = 0:0.1:10; % Time span of 12 seconds, 0.1s increments

d0 = [-1;0];      % Desired starting direction
CoM = [22.68; -15.12]; % CoM location wrt centroid
% CoM = [18.9; 18.9]; % DOESNT WORK YET
% CoM = [-15.12; 7.56];
% CoM = [-11.34; -17.01];

detachedPoint = [-2; 0.5]; % Detached starting point for agents

Rzd = @(q)[cosd(q), -sind(q); sind(q), cosd(q)];


%% Visual settings - Generate environment/plot based on supplied limits
scene = generateEnvironment([-250 250 -250 450]); %,'dual');


%% Object (payload) information and initialization
mo = 1;         % Payload mass in kg
Io = 1;         % Payload inertia in kgm^2
uk = 0.2;       % Coefficient of kinetic friction between the surface and object
Ro = 86/2;       % Body radius of the object

% ObjectBodyPoints = [po_x po_y; po_x+1 po_y; po_x+1 po_y+1; po_x po_y+1];
ObjectBodyPoints = [];

O = payload('bodyPoints',Ro*ObjectBodyPoints,'mass',mo,'inertia',Io,'uk',uk,'bodyColor',scene.O,...
    'bodyRadius',Ro*2, 'com',CoM);%, 'prev_theta', po_0(3));
O.move(po_0,dpo_0);


%% Obstacle(s) information and initialization
VQ1 = [];
Q(1) = obstacle('Vertices',VQ1,'bodyColor',scene.Q);


%% Robot information and initialization
delta = 10;   % Robot radius in m
gamma = 0.2;    % Robot's vision range in m
Kp = 10;        % Proportional gain of the PD controller (Manipulation)
Kd = 2;         % Derivative gain of the PD controller (Manipulation)
fmax = 5;       % Maximum force of the robot in N

max_theta = 10; % Threshold for measured rotation
min_theta = 1;  % Threshold to STOP simulation

% Array of length numAgents+1, with last entry empty (e.g. N long)
qq = linspace(0,2*pi,N+1); qq(end) = [];

% Agent attachment points
aPoints = []; itr = 0;
while(size(aPoints,1)<N)
    aPoints = O.getBodyPoint(N+itr)
    itr = itr+1;
end

% Calculating bounds tangent to payload at attachment point (technically perpendicular to 'r')
negBound = Rzd(-90) * -aPoints';
posBound = Rzd(90) * -aPoints';

for i=1:N
    % Create robot object with supplied parameters
    A(i) = robot('ID',i,'delta',delta,'gamma',gamma,'Kp',Kp,'Kd',Kd,'fmax',fmax,'AttachedColor',scene.Aattched,...
        'DetachedColor',scene.Adetached,'AvoidColor',scene.Aavoid,'FmanColor',scene.Fman,'FavoidColor',scene.Favoid, ...
        'p_attach',[aPoints(i,:) pi+qq(i)]','theta_meas_prev', O.p(3),'negBound',negBound,'posBound',posBound,...
        'desired_direc', d0, 'max_theta', max_theta, 'min_theta', min_theta);
    
    % Move robot to attachment point on object
    A(i).move([aPoints(i,:) pi+qq(i)]);
%     A(i).move([detachedPoint; 0]); % To begin detached
    A(i).setr(aPoints(i,:),O.p); % Attachment point wrt centroid
end

O.r = A(1).r; % Set object attachment property equal to agent 1's property
% O.r_com = A(1).r - CoM;


%_____________________________________________________________________________________________
%% Simulation
%_____________________________________________________________________________________________

y0 = [po_0;dpo_0]; % Initial object position and velocity

for i=1:N 
   y0(6*i+1 : 6*i+3,1) = A(i).p; % Add three rows consisting of the robot's position
end

%%% TEMP TEST
global Bounds
Bounds = [0, 0, 0, 0, 0];
%%%%

[t,y] = ode45(@(t,y) systemDynamics(t,y,pd,A,O,Q),tspan,y0);

% Remove 'payload' obstacle visual
VQ1 = [];
Q(1) = obstacle('Vertices',VQ1,'bodyColor',scene.Q);

fprintf('\n\n _____________________ END OF ODE45 ______________________________________\n\n')

%% Reconstruct CoM Location and Bounds
com_loc = zeros([length(t),2]); bounds = zeros([length(t),4]); desired_direction = zeros([length(t),2]);
for n=1:length(tspan)
    com_loc(n,:) = y(n,1:2)' + [cos(y(n,3)) -sin(y(n,3)); sin(y(n,3)) cos(y(n,3))] * CoM;
end

reconstruct_bounds_GLOBAL;

%% Results
% input('Press Enter to Proceed...');

% Plot the obstacles:
for j=1:length(Q)
    Q(j).plot(scene.ax);
end

% Plot the object:
O.plot(scene.ax);

% Plot the agent(s):
for i=1:N
    A(i).plot(scene.ax);
end

% Axes for desired point
quiver(pd(1)*[1 1],pd(2)*[1 1], O.bodyRadius*[cos(pd(3)) -sin(pd(3))], O.bodyRadius*[sin(pd(3)) cos(pd(3))], 0, ...
    'Color',scene.pd);

% Initialize handle for CoM location point
c = scatter(0,0);

% Move the agent(s) and object and CoM
for n=1:length(t)
    delete(c)
    O.move(y(n,1:3));
    for i=1:N
        position = y(n, 6*i+1 : 6*i+3);
        bound1 = bounds(n,1:2);
        bound2 = bounds(n,3:4);
        direction = desired_direction(n,:);

        A(i).move(position,pd,O,bound1,bound2,direction);
    end
    c = scatter(com_loc(n,1),com_loc(n,2),'ko','MarkerFaceColor','r','MarkerFaceAlpha',1,'DisplayName','CoM');
    % Expand plot window when system moves out of frame
    moveWindow;

    pause(0.07);
end


