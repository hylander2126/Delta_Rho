clc; clear; close all;

addpath(genpath(sprintf('%s',pwd)));


delete(instrfind('Type', 'serial'));
BaudRate = 57600;
s1 = serial('COM6','BaudRate',BaudRate,'DataBits',8, 'StopBits',1);
fopen(s1);

dllPath = fullfile('\\research.wpi.edu\srl\OptiTrack\MATLAB Connection\NatNet_SDK_2.8\NatNetSDK\lib\x64\NatNetML.dll');
assemblyInfo = NET.addAssembly(dllPath);


theClient = NatNetML.NatNetClientML(0);
HostIP = char('130.215.48.201');
theClient.Initialize(HostIP, HostIP);


f1 = figure();
hold on
axis equal;
stop = uicontrol('style','toggle','string','stop');
axis([-0.1 1.3 -0.1 1.3]);
grid on


xlabel('x'); ylabel('y');

%Q = [90 90+120 90+240]; % all the exps!
Q = [0 90 135 225 315]; % [0 0+90 90+45 135+90 225+90]

P = 160*[cosd(Q);sind(Q)];

%P=[0 -112.58 112.58; 130 -65 -65];

N = 5;


object.x.data = [];
object.xd.data=[];

object.dx = [0 0 0]';
object.dxd = [0 0 0]';


failedRobotList = [ ];
fauilerTime = [300];

for n=1:N
    
    robot(n).ID = n;
    robot(n).Kp = [5 5 5]';
    robot(n).Kd = [0.5 0.5 0.5]';
    
    
    robot(n).x.data = [100 200 -300]';
    robot(n).x.type = 'int16';
    robot(n).x.convertor = @(x)int16(x);
    
    robot(n).xd.data = [220 -500 450]';
    robot(n).xd.type = 'int16';
    robot(n).xd.convertor = @(x)int16(x);
    
    robot(n).u.data = [];
    robot(n).u.type = 'uint8';
    robot(n).u.convertor = @(x)uint8(x);
   
    robot(n).dx = [0 0 0]';
    robot(n).dxd = [0 0 0]';
% %     
% %     % Centralized
%     CentralizedJacobian = construct_jacobian(P);
%     robot(n).J = CentralizedJacobian(:,:,n);
%     
% % %     % Decentralized
    robot(n).J = construct_jacobian(P(:,n));
% %    
%     
    robot(n).pJ_ = pinv(robot(n).J);
    
    robot(n).dg = 70;
end

for n=1:N+1
    arrow(n) = quiver(1,1,1,1,0,'MaxHeadSize',10,'LineWIdth',2);
end


frameOfData = theClient.GetLastFrameOfData();

% Get and Set robot desired position robot.xd
% for n=1:N
%     R = frameOfData.RigidBodies(n);
%     x = R.x;
%     y = R.y;
%     Q = [R.qw R.qx R.qy R.qz];
%     [q,~,~] = quaternions2euler(Q);
%     
%     robot(n).xd.data = [x*1000;y*1000;q*57.2958];
%     u = 0.2*cos(q);
%     v = 0.2*sin(q);
%     set(arrow(n),'xdata',x,'ydata',y,'udata',u,'vdata',v)
% end



R = frameOfData.RigidBodies(N+1);
x = R.x;
y = R.y;

Q = [R.qw R.qx R.qy R.qz];
[q,~,~] = quaternions2euler(Q);
object.xd.data = [600;700;2*57.2958];
object.dxd=[0;0;0];
p_x=object.xd.data;
u = 0.2*cos(q);
v = 0.2*sin(q);
set(arrow(N+1),'xdata',x,'ydata',y,'udata',u,'vdata',v);
   



%__________________________________________________________________________

% initPos(1) = figure('Name','R1');
% initPos(2) = figure('Name','R2');
% initPos(3) = figure('Name','R3');
% initPos(4) = figure('Name','O');
% 
% init_data = zeros(100,3,4);
% 
% while(~get(stop,'value'))
%     
%     frameOfData = theClient.GetLastFrameOfData();
%     R = frameOfData.RigidBodies(N+1);
%     x = R.x;
%     y = R.y;
%     
%     Q = [R.qw R.qx R.qy R.qz];
%     [q,~,~] = quaternions2euler(Q);
%     
%     init_data(1:end-1,:,N+1) = init_data(2:end,:,N+1); 
%     init_data(end,:,N+1)=[x*1000;y*1000;q*57.2958]';
%     
%     for n=1:N
%         R = frameOfData.RigidBodies(n);
%         x = R.x;
%         y = R.y;
%         Q = [R.qw R.qx R.qy R.qz];
%         [q,~,~] = quaternions2euler(Q);
%         init_data(1:end-1,:,n) = init_data(2:end,:,n);
%         init_data(end,:,n) = [x*1000;y*1000;q*57.2958]';
%     end
%     
%     for n=1:N+1;
%     figure(initPos(n));
%         for i=1:3
%             subplot(3,1,i);
%             plot(init_data(:,i,n));
%         end
%     end
%  
%     drawnow();
% 
% end
% 
% close(initPos);
% stop.Value = 0;

expr_data=[];
expr_time = 0;


frameOfData = theClient.GetLastFrameOfData();
R = frameOfData.RigidBodies(N+1);
x = R.x;
y = R.y;
Q = [R.qw R.qx R.qy R.qz];
[q,~,~] = quaternions2euler(Q);
object_x0 = [x*1000;y*1000;q*57.2958];

tic;
while(~get(stop,'value'))
    
    frameOfData = theClient.GetLastFrameOfData();
    R = frameOfData.RigidBodies(N+1);
    x = R.x;
    y = R.y;
    
    Q = [R.qw R.qx R.qy R.qz];
    [q,~,~] = quaternions2euler(Q);
   
    time=toc; 

    object.x.data = [x*1000;y*1000;q*57.2958];
%     object.dx=(object.x.data-p_x)/time;
%     object.dx=0;
%     p_x=object.x.data;
%     
%     
%     object.xd.data = [object_x0(1)+10*expr_time(end); object_x0(2)+100*sin(expr_time(end)/10); 0];
%     object.xd.data(3) = object.x.data(3);
%     
    tic;

    u = 0.2*cos(q);
    v = 0.2*sin(q);
    
%     x_hist(:,1:end-1) = x_hist(:,2:end);
%     x_hist(:,end) = object.x.data;
%     
%     dx_hist(:,1:end-1) = dx_hist(:,2:end);
%     dx_hist(:,end) = object.dx;
%     
    expr_time(end+1) = time + expr_time(end); %#ok<SAGROW>
    expr_data(end+1,:,N+1)=object.x.data'; %#ok<SAGROW>
    
    set(arrow(N+1),'xdata',x,'ydata',y,'udata',u,'vdata',v)
    
    
    %% UPDATE ROBOT DATA X and U
    for n = 1:N
        
        R = frameOfData.RigidBodies(n);
        x = R.x;
        y = R.y;
        Q = [R.qw R.qx R.qy R.qz];
        [q,~,~] = quaternions2euler(Q);
        
        robot(n).x.data = [x*1000;y*1000;q*57.2958];
        robot(n)=updateRobot(robot(n),object,'Force');
        
        %__________________________________________________________________
        % Fauiler mode
        failedRobot = false;
        for r = failedRobotList
            if (n == r)
                failedRobot = true;
                break
            end
        end
        
        if(expr_time(end) >= fauilerTime(1) && expr_time(end) <= fauilerTime(2) && failedRobot)
            robot(n).u.data = zeros(6,1);
        end
        %__________________________________________________________________
        
        SerialCommunication(s1,robot(n),192,'u');
        
        u = 0.2*cos(q);
        v = 0.2*sin(q);
        set(arrow(n),'xdata',x,'ydata',y,'udata',u,'vdata',v)
        
        
        expr_data(end,:,n)=robot(n).x.data';
    end
 
    drawnow();

end


expr_time(end) = [];


for n=1:N
    robot(n).u.data = zeros(6,1);
    SerialCommunication(s1,robot(n),192,'u');
end


close(f1);


theClient.Uninitialize; % disconnect
theClient.delete;
fclose(s1);


labels = {'r1','r2','r3','r4','r5','O'};
ax_labels = {'x','y','\theta'};

figure('Name','system overview');
hold on
for n=1:N+1
    axis equal
    grid on
    plot(expr_data(:,1,n),expr_data(:,2,n));
end
legend(labels);

for n=1:N+1
    figure('Name',labels{n});
    for i=1:3
        subplot(3,1,i);
        plot(expr_time, expr_data(:,i,n));
        ylabel(ax_labels{i});
    end
end
    
    
