clc; clear; close all;

addpath(genpath(sprintf('%s',pwd)));


delete(instrfind('Type', 'serial'));
BaudRate = 57600;
s1 = serial('COM4','BaudRate',BaudRate,'DataBits',8, 'StopBits',1);
fopen(s1);

% dllPath = fullfile('Z:\OptiTrack\MATLAB Connection\NatNet_SDK_2.8\NatNetSDK\lib\x64\NatNetML.dll');
% assemblyInfo = NET.addAssembly(dllPath);
% 
% 
% theClient = NatNetML.NatNetClientML(0);
% HostIP = char('130.215.48.201');
% theClient.Initialize(HostIP, HostIP);

f1 = figure();
axis equal; hold on;
axis([-0.1 1.3 -0.1 1.3]);
grid on
stop = uicontrol('style','toggle','string','stop');
xlabel('x'); ylabel('y'); zlabel('z');

N = 5;
Q = [];
% Rz = @(q)[cosd(q) -sind(q) 0; sind(q) cosd(q) 0; 0 0 1];

for i=1:N
    robot(i) = struct('ID',i,'x',[],'xd',[],'u',[]);
    arrow(i) = quiver(1,1,1,1,0,'MaxHeadSize',10,'LineWIdth',2);
end
% object = struct('ID','object','x',[]);
% arrow(4) = quiver(1,1,1,1,0,'MaxHeadSize',10,'LineWIdth',2,'color','b');


% frameOfData = theClient.GetLastFrameOfData();
% 
% for i=1:N
%     R = frameOfData.RigidBodies(i);
%     x = R.x;
%     y = R.y;
%     Q = [R.qw R.qx R.qy R.qz];
%     [q,~,~] = quaternions2euler(Q);
%     robot(i).xd = [x*1000;y*1000;q*57.2958];
%     robot(i).x = robot(i).xd;
%     u = 0.2*cos(q);
%     v = 0.2*sin(q);
%     set(arrow(i),'xdata',x,'ydata',y,'udata',u,'vdata',v);
%     
% end


SerialCommunication(s1,robot(1),112); % send start!
% SerialCommunication(s1,robot(2),112); % send start!
% SerialCommunication(s1,robot(3),112); % send start!



input('Enter')
while(~get(stop,'value'))
    frameOfData = theClient.GetLastFrameOfData();
    
    for i=1:N
        R = frameOfData.RigidBodies(i);
        x = R.x;
        y = R.y;
        Q = [R.qw R.qx R.qy R.qz];
        [q,~,~] = quaternions2euler(Q);
        
        
            robot(i).x = [x*1000;y*1000;q*57.2958];
            robot(i)=updateRobot(robot(i));
            SerialCommunication(s1,robot(i),192,'u');
      
        u = 0.2*cos(q);
        v = 0.2*sin(q);
        set(arrow(i),'xdata',x,'ydata',y,'udata',u,'vdata',v);
        
    end
    
    %     O = frameOfData.RigidBodies(4);
    %     x = O.x;
    %     y = O.y;
    %     Q = [O.qw O.qx O.qy O.qz];
    %     [q,~,~] = quaternions2euler(Q);
    %     object.x = [x*1000;y*1000;q*57.2958];
    
    %     SerialCommunication(s1,object,160,'x'); % sending object poistion
    %     SerialCommunication(s1,robot,144,'x'); % sending robot positions
    %
    %     u = 0.2*cos(q);
    %     v = 0.2*sin(q);
    %     set(arrow(4),'xdata',x,'ydata',y,'udata',u,'vdata',v)
    
    %     output = SerialCommunication(s1,robot(1),48);
    %     disp('What we get:');
    %     disp(output{1})
    drawnow();
end

close(f1);

theClient.Uninitialize; % disconnect
theClient.delete;
fclose(s1);