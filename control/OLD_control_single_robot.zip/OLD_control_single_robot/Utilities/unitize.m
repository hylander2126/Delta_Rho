function unitized_vector = unitize(vect1)
%UNITIZE Function to turn vector into unit vector
unitized_vector = vect1/norm(vect1);
end

