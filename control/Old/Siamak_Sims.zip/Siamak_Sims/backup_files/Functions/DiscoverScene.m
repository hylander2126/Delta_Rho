function [robot,S] = DiscoverScene(vid,robot,markers,tracking,settings)



if(size(vid,3)==1)
    IM = getsnapshot(vid);
else
    IM = vid;
end

C = ExtractCentriod(RedObjectDetector(IM,markers));

[S,~] = ObjectTracking(C,[],0,tracking.MLF,tracking.R);
   
robot = RobotTracking(robot,S,settings);


f1 = figure(); 
imshow(IM); 
hold on

list = 1:length(robot);

for n = 1:length(robot)
    x_ = robot(n).x;
    quiver(x_(1),x_(2),200*cos(x_(3)),200*sin(x_(3)),0,'LineWidth',2,'MaxHeadSize',10);
    hold on
end

for n = 1:length(robot)
    
    if(n==1)
        message = 'the object.';
        color = 'w';
    else
        message = sprintf('robot #%d.',n-1);
        color = 'c';
    end
   
    title(['Select bounding box of ',message]);
    drawnow();
    [xb,yb] = ginput(2);
    xbox = [min(xb) min(xb) max(xb) max(xb) min(xb)];
    ybox = [min(yb) max(yb) max(yb) min(yb) min(yb)];
    box(n) = plot(xbox,ybox,'color',color,'LineWidth',2);
    drawnow();
    
    for j = list
        d(j) = norm([mean(xb);mean(yb)]-robot(j).x(1:2));
    end
    
    [~,min_d] = min(d);
    
    if(n==1)
        robot(min_d).ID = 'object';
    else
        robot(min_d).ID = n-1;
    end
    
end

Cx = 150*cosd(0:20:360);
Cy = 150*sind(0:20:360);

for n = 1:length(robot)
    
    if(isnumeric(robot(n).ID))
        color = [116 0 143]/255;
        text_ = ['Robot #',num2str(robot(n).ID)];
    else
        color = [35 190 200]/255;
        text_ = robot(n).ID;
    end
    
    set(box(n),'xdata',Cx + robot(n).x(1),'ydata',Cy + robot(n).x(2));
    set(box(n),'color',color,'LineWidth',4);
    
    text(robot(n).x(1) - 150, robot(n).x(2) - 150,text_,'fontsize',15,'color','w');
end

uiwait();