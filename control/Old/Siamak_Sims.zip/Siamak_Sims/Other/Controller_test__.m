clear; close;

delete(instrfind('Type', 'serial'));

BaudRate = 57600;

s1 = serial('COM4','BaudRate',BaudRate,'DataBits',8, 'StopBits',1);
fopen(s1);


if(s1.BytesAvailable ~= 0)
    fread(s1,s1.BytesAvailable,'int8');
    
end


X = [1; 0 ; 0];

fwrite(s1,85, 'uint8');
fwrite(s1,241, 'uint8');

fwrite(s1,X(1), 'int16');
fwrite(s1,X(2), 'int16');
fwrite(s1,X(3), 'int16');

pause(0.01);

fwrite(s1,85, 'uint8');
fwrite(s1,113, 'uint8');
pause(1);

data = fread(s1,s1.BytesAvailable/2,'int16');

disp(data);



fclose(s1);