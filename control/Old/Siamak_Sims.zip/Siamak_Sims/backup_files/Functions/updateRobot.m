function [robot] = updateRobot(robot,object,scenario)


for n=1:length(robot)
    
    Rz = @(q)[cosd(q),-sind(q),0;sind(q),cosd(q),0;0 0 1];
     J_rf = [-1.7322, 1, 1; 0, -2, 1; 1.7322, 1, 1];
      J_r = 3*[-0.5774    0.7314    5.7504;    0   -0.2686    5.7504;   0.5774    0.7314    5.7504];
 
    switch scenario
        case 'Force'
            r = [robot(n).J(3,2);-robot(n).J(3,1)];
            r = r/norm(r);
            
            noW = Rz(object.x.data(3))*[r;0];
            nrW = Rz(robot.x.data(3))*[-1;0;0];
            
            e_r = -1+acos(noW(1:2)'*nrW(1:2));
            
            e_o = Rz(object.x.data(3))'*(object.xd.data - object.x.data);
            de_o = Rz(object.x.data(3))'*(object.dxd - object.dx);
            
            phi = robot(n).Kp.*e_o + robot(n).Kd.*de_o;
            f_o = robot(n).pJ_(1:2,:)*phi;
            f_r = Rz(object.x.data(3) - robot(n).x.data(3))*[f_o;0];
            
            u_r(1:2,1) = f_r(1:2);
            u_r(3,1) = 10*e_r;
            
        case 'Position'
%             e = (robot(n).xd.data - robot(n).x.data);
%             de = (robot(n).dxd - robot(n).dx);
        otherwise
%             u_r = [0;0;0];
    end
    
    f = J_r*u_r;
    
    for k=1:3
        if(f(k) >= 0)
            robot(n).u.data(2*k-1,1) = 0;
            robot(n).u.data(2*k,1) = uint8(abs(f(k)));
        else
            robot(n).u.data(2*k-1,1) = uint8(abs(f(k)));
            robot(n).u.data(2*k,1) = 0;
        end
    end
    
end