clc; clear all; close all;

addpath('\\research.wpi.edu\srl\Projects\Ant\Delta_Rho\Motion capturing and communication\IJRR_Experiments\Scalability-500_500_20');

RobotPopulation = [5];
type = {'Cent'};
extension = '300_300_90.mat';

lineType = {'-','--'};

cm = parula(length(RobotPopulation)+1);

figure(); hold on;
a1 = 0.5;
a0 = 0.1;
alpha = @(t,data) (a1-a0)/(data(end)-data(1))*(t-data(1))+a0;

t_max = [797];

for exp = 1 : length(RobotPopulation)
    for itr = 1 : length(type)
        clear expr_data expr_time
        fileName = sprintf('%d_%s_%s',RobotPopulation(exp),type{itr},extension);
        load(fileName,'expr_data','expr_time');
        
        N = RobotPopulation(exp)+1;
        subplot(1,1,exp); hold on;
        axis([-250 500 -500 200 0 5]); grid on% box on
        time = expr_time(expr_time <= t_max(exp));
        ct = cool(length(time));
        for t=1:length(time);
            
            %plotObject(expr_data(t,:,N)-[500 500 20],cm(exp,:),alpha(time(t),time));
            plotObject3D(expr_data(t,:,N)-[500 500 20],time(t),ct(t,:),0.2);
        end
        set(gca,'FontName','Times New Roman');
        xlabel({'x [mm]'},'FontName','Times New Roman');
        ylabel({'y [mm]'},'FontName','Times New Roman');
        zlabel({'t [s]'},'FontName','Times New Roman');
        view(3)
        daspect([1 1 0.01]);
%         plot3(expr_data(:,1,N)-500,100*ones(size(expr_data(:,1,N))),expr_time,'color',[0, 0.45, 0.74],'LineWidth',2);
%         plot3([0 0],[100 100],[0 time(end)],'--','color',[0.9290, 0.6940, 0.1250],'LineWidth',2);
%         plot3(150*ones(size(expr_data(:,2,N))),expr_data(:,2,N)-500,expr_time,'color',[0, 0.45, 0.74],'LineWidth',2);
%         plot3([150 150],[0 0],[0 time(end)],'--','color',[0.9290, 0.6940, 0.1250],'LineWidth',2);
        plot3(expr_data(:,1,N)-500,expr_data(:,2,N)-500,zeros(size(expr_data(:,2,N))),'color',[0, 0.45, 0.74],'LineWidth',2);
%         plot3([0 0],[0 0],[0 time(end)],'color','r','LineWidth',2);
    end
end

