function [Robot] = update_robot(t,Robot,s1)

%% TODO - THIS DOESNT CORRESPOND TO THE ROBOT JACOBIAN WE CALCULATE IN THAT FUNCTION. THE AXES ARE WRONG...
% RECALL AGENT FRAME:
%                      _         O   <- Marker 1
%                      |        / \
%                      |       /   \
%                   2d |      /     \
%                      |     /       \
%                      |    /         \
%   Marker 3 (2) ->    _   O y<--*     O  <- Marker 2 (3)
%                                |
%                                v
%                                x
%
%                          |<--- d --->|

global force_data PD_data;

%% Calibrate sensors resting state
if t < 1.5
    if Robot.rest_angles == 0
        fprintf("Calibrating force sensor. Do not touch robot...")
    end
    fprintf('.')
    [Robot.rest_angles, Robot.rest_ee] = sensor_kinematics(s1, Robot, 1);
    return

elseif t < 1.75
    u_r = [170;0;0];

else    
    %% Run Demo
    if isempty(force_data)
        fprintf('\n\n')
        disp('BEGIN DEMO')
    end
    
    % Convert sensor voltages to applied force and direction
    [d,f] = sensor_kinematics(s1, Robot, 0);
    % Apply deadzone
    if abs(f) < Robot.deadzone %&& abs(d(2)) < 0.3
        d = [0;0];
    end
    Robot.d_prev = d;
    Robot.f_prev = f;

    if ischar(f)
        Robot.stop = true;
        return
    end
    %% Open loop control since we don't have position feedback
    Phi = Robot.Kp * d;
    
    % Assign robot direction
    u_r = [Phi; 0];
    
    
    %% Null-space control / attitude adjustment
    % Rotate in SAME direction y-force is measured
%     d(2)
%     u_r(3) = -2*Robot.Kw*sign(d(2));
    u_r(3) = -610*d(2);                             % IF LINEAR, NEEDS TUNING
%     u_r(3) = -sign(d(2)) * 700*log(abs(d(2))+1);

%     u_r(3) = 0;

    % Record force data and PD Data for plotting separately
    force_data = [force_data; t, f*d'];
    PD_data = [PD_data; Phi'];
end

%% TODO create a data table for rotation response vs sensor. Remember u_r(3) has to first cancel out the desired direct.

% u_r = [0;0;0];


%% Calculate motor torque values using ROBOT Jacobian
f = Robot.J_r*u_r;


%% Assign robot motor torques | k=1 front left; k=2 rear; k=3 front right
for k=1:3
    if(f(k) >= 0)
        Robot.u.data(2*k-1,1) = 0;
        Robot.u.data(2*k,1) = uint8(abs(f(k)));
    else
        Robot.u.data(2*k-1,1) = uint8(abs(f(k)));
        Robot.u.data(2*k,1) = 0;
    end
end

%% SEND serial communication to robot
SerialCommunication(s1,Robot,192,'u');

end
