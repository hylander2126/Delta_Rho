%% Testing what construct_jacobian does and the resulting matrix for
%% decoding the PD controller in updateRobot.m

% I assume radii where the agents are attached to the object
Q = [0 90 135 225 315] % [0 0+90 90+45 135+90 225+90]

% I assume coordinates of where the agents are attached with circle r=160
P = 160*[cosd(Q);sind(Q)]

% Construct the Jacobian and the pseudo-inverse of the jacobian
J = construct_jacobian(P(:,1))
pJ_ = pinv(J)

fo = pJ_(1:2,:) % times phi from PD controller

% Assign Robot J and pJ_ properties for use later
% robot(1).J = J;
% robot(1).pJ_ = pJ_;

% Plot P around a circle
% plot(P(1,:),P(2,:))