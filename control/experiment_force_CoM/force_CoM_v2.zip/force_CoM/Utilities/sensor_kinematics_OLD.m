function [direction, force] = sensor_kinematics(sensor, rest_volts, rest_ee)
    % rest_volts in volts and rest_ee in default units (mm)

    % Rot matrix fn
    Rz = @(th) [cos(th), -sin(th); sin(th), cos(th)];

    %% Convert current sensor data from voltage to radians, add offset (0deg is 270 wrt x-axis), and wrap to 2Pi
    % Offset - roughly 270 degrees
    offset = 280;
    
    theta1 = wrapTo2Pi(mapfun(sensor(1), 0, 1023, 0, deg2rad(330)) + deg2rad(offset));
    theta2 = wrapTo2Pi(mapfun(sensor(2), 0, 1023, 0, deg2rad(330)) + deg2rad(offset));

    s1_rest = wrapTo2Pi(mapfun(rest_volts(1), 0, 1023, 0, deg2rad(330)) + deg2rad(offset)); % TODO ON SETUP, MAKE SURE S1 IS 'LEFT' POT
    s2_rest = wrapTo2Pi(mapfun(rest_volts(2), 0, 1023, 0, deg2rad(330)) + deg2rad(offset));
    
    % Get difference between current reading and resting angle
    dTheta1 = s1_rest - theta1;
    dTheta2 = s2_rest - theta2;
    
    %% Define problem constraints
    % Spring constant calculation
    % For the following spring: https://www.mcmaster.com/9271K665/
    maxTorque = 0.402; % in-lb
    maxDeflection = pi; % 180 degrees
    
    maxTorque = maxTorque * (25.4/1) * (4.448/1); % Convert in-lb to N-mm
    k = maxTorque/maxDeflection; % N-mm/rad
    
    % Define link lengths
    l1 = 25;
    l2 = 40;
    l3 = 40;
    l4 = 25;
    l5 = 22.84;
    
    % First and Last point coordinates
    A = [0; 0];
    E = [l5; 0];
       
    %% Calculate coordinates of all other joints
    % Coordinates of joint 2 and 4
    B = [l1*cos(theta1) ; l1*sin(theta1)];
    D = [l5 + l4*cos(theta2) ; l4*sin(theta2)];
    
    % Get distance between joints 2 and 4
    d = norm(D-B);
    
    % Calculate angle between d and l2
    alpha = acos((l2.^2 + d.^2 - l3.^2)./(2*l2.*d));
    
    % Get "V" vector with length l2 along d
    v = l2*(D - B)./d;
    
    % Calculate end effector x,y by rotating V vector by alpha
    C = Rz(alpha) * v + B;
    
    % Calculate angle between l1 & l2 and l4 & l3
    gamma1 = acos(dot(C-B, -B) / (norm(C-B)*norm(B)));               % Angle between link 1 & 2
    gamma2 = acos(dot(C-D, -(D-E)) / (norm(C-D)*norm(D-E)));         % Angle between link 3 & 4
%     gamma3 = acosd(dot(Ftemp1,C1)/(norm(C1)*norm(Ftemp1)));     % Angle between link 2 & Fapp
%     gamma4 = acosd(dot(Ftemp2,C2)/(norm(C2)*norm(Ftemp2)));     % Angle between link 3 & Fapp

    Fapp1 = (-k*dTheta1 / (l1*sin(gamma1)));
    Fapp2 = (-k*-dTheta2 / (l4*sin(gamma2)));
    
    force = Fapp1 + Fapp2;
    
    %% Calculate direction of incoming force
    direction = (rest_ee - C) / norm(rest_ee - C);
    if isnan(direction)
        direction = [0;0];
    end
    
    
end
