clc; clear; close; 

N = 5;


failedRobotList = [1 2 3 5];
fauilerTime = [8 10];

expr_time = 0;

tic;
while(expr_time <= 15)
    
    
    time=toc;
    tic;
    pause(1);
      
    expr_time(end+1) = time + expr_time(end); %#ok<SAGROW>
    
    
    for n = 1:N
        
        %__________________________________________________________________
        % Fauiler mode
        failedRobot = false;
        for r = failedRobotList
            if (n == r)
                failedRobot = true;
                break
            end
        end
        
        if(expr_time(end) >= fauilerTime(1) && expr_time(end) <= fauilerTime(2) && failedRobot)
            fprintf('t = %.4f ; robot = %d is dead\n',expr_time(end),n);
        else
            fprintf('t = %.4f ; robot = %d is alive\n',expr_time(end),n);
        end
        %__________________________________________________________________
        
    end
    
    fprintf('________________________________________________________\n');

end